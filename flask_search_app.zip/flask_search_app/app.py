import os
import re
from flask import Flask, request, redirect, url_for, render_template, flash, send_from_directory
from werkzeug.utils import secure_filename
from whoosh import index
from whoosh.fields import Schema, TEXT, ID
from whoosh.qparser import QueryParser

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['INDEX_DIR'] = 'indexdir'
app.config['SECRET_KEY'] = 'your_secret_key'  # 실제 환경에서는 안전한 값으로 변경하세요.

ALLOWED_EXTENSIONS = {'txt', 'pdf', 'doc', 'docx', 'pptx', 'csv'}

# Whoosh 스키마 정의: 파일명과 문서의 전체 내용 저장
schema = Schema(filename=ID(stored=True, unique=True), content=TEXT(stored=True))

# 업로드 폴더와 인덱스 폴더가 없으면 생성
if not os.path.exists(app.config['UPLOAD_FOLDER']):
    os.makedirs(app.config['UPLOAD_FOLDER'])

if not os.path.exists(app.config['INDEX_DIR']):
    os.makedirs(app.config['INDEX_DIR'])
    ix = index.create_in(app.config['INDEX_DIR'], schema)
else:
    try:
        ix = index.open_dir(app.config['INDEX_DIR'])
    except Exception as e:
        ix = index.create_in(app.config['INDEX_DIR'], schema)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def extract_text(file_path):
    ext = file_path.rsplit('.', 1)[-1].lower()
    text = ""
    try:
        if ext in ['txt']:
            with open(file_path, 'r', encoding='utf-8') as f:
                text = f.read()
        elif ext in ['csv']:
            import csv
            with open(file_path, 'r', encoding='utf-8') as f:
                reader = csv.reader(f)
                rows = [', '.join(row) for row in reader]
                text = "\n".join(rows)
        elif ext in ['pdf']:
            import PyPDF2
            with open(file_path, 'rb') as f:
                pdf_reader = PyPDF2.PdfReader(f)
                for page in pdf_reader.pages:
                    page_text = page.extract_text()
                    if page_text:
                        text += page_text
        elif ext in ['docx']:
            import docx
            doc = docx.Document(file_path)
            paragraphs = [p.text for p in doc.paragraphs]
            text = "\n".join(paragraphs)
        elif ext in ['pptx']:
            from pptx import Presentation
            prs = Presentation(file_path)
            text_runs = []
            for slide in prs.slides:
                for shape in slide.shapes:
                    if hasattr(shape, "text"):
                        text_runs.append(shape.text)
            text = "\n".join(text_runs)
        elif ext in ['doc']:
            try:
                import textract
                text = textract.process(file_path).decode('utf-8')
            except Exception as e:
                text = f"텍스트 추출 중 에러 발생: {e}"
        else:
            text = "지원하지 않는 파일 형식입니다."
    except Exception as e:
        text = f"텍스트 추출 중 에러 발생: {e}"
    return text

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('파일이 업로드되지 않았습니다.')
            return redirect(request.url)
        file = request.files['file']
        if file.filename == '':
            flash('파일명이 없습니다.')
            return redirect(request.url)
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(file_path)
            flash('파일 업로드 성공!')

            # 파일에서 텍스트 추출 후 Whoosh 인덱스에 추가
            content = extract_text(file_path)
            writer = ix.writer()
            writer.update_document(filename=filename, content=content)
            writer.commit()
            
            return redirect(url_for('index'))
        else:
            flash('지원하지 않는 파일 형식입니다.')
            return redirect(request.url)
    return render_template('upload.html')

@app.route('/search', methods=['GET', 'POST'])
def search():
    results = {}
    query = ""
    if request.method == 'POST':
        query = request.form.get('query')
        with ix.searcher() as searcher:
            qp = QueryParser("content", schema=ix.schema)
            q = qp.parse(query)
            hits = searcher.search(q, limit=None)
            for hit in hits:
                filename = hit['filename']
                content = hit['content']
                # 문장을 분리하여 문서의 처음 5문장과 검색어가 포함된 문장을 추출
                sentences = re.split(r'(?<=[.!?])\s+', content)
                first_five = sentences[:5]
                query_sentences = [s for s in sentences if query.lower() in s.lower()]
                snippet = []
                for s in sentences:
                    if s in first_five or s in query_sentences:
                        if s not in snippet:
                            snippet.append(s)
                snippet_text = " ".join(snippet)
                results[filename] = snippet_text
    return render_template('search.html', query=query, results=results)

@app.route('/download/<filename>')
def download_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename, as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True)
