"""
2D Heat Diffusion Simulation Engine for Hydrogen Chamber
"""
import numpy as np


class HeatSimulation:
    """2D Heat diffusion simulation with convection and heat generation."""

    def __init__(self):
        # Grid parameters
        self.nx = 51
        self.ny = 51
        self.nt = 100

        # Chamber dimensions (2m x 2m)
        self.chamber_length = 2.0
        self.chamber_width = 2.0

        # Gas properties (Hydrogen)
        self.rho_gas = 0.0898      # kg/m^3 density
        self.cp_gas = 14300        # J/(kg K) specific heat
        self.k_gas = 0.18          # W/(m K) thermal conductivity

        # Heat transfer
        self.h_wall = 0.05         # W/(m^2 K) wall-air convection coefficient
        self.T_ambient = 393       # K (120 C) ambient temperature

        # Heat generation
        self.q_dot_heater = 3000   # W/m^3 heater power density

        # Stability factor
        self.sigma = 0.2

        # Results storage
        self.T_history = []
        self.time_points = []
        self.stats_history = []

        # Computed values
        self._compute_derived_values()

    def _compute_derived_values(self):
        """Compute derived values from parameters."""
        self.dx = self.chamber_length / (self.nx - 1)
        self.dy = self.chamber_width / (self.ny - 1)

        self.x = np.linspace(0, self.chamber_length, self.nx)
        self.y = np.linspace(0, self.chamber_width, self.ny)

        # Thermal diffusivity
        self.alpha = self.k_gas / (self.rho_gas * self.cp_gas)

        # Chamber geometry
        self.A_chamber = self.dx * self.dy
        self.P_chamber = 4 * (self.dx + self.dy)

        # Time step (CFL condition)
        self.dt = self.sigma * self.dx**2 / self.alpha

    def set_parameters(self, **kwargs):
        """Update simulation parameters."""
        for key, value in kwargs.items():
            if hasattr(self, key):
                setattr(self, key, value)
        self._compute_derived_values()

    def get_info(self):
        """Get simulation info as dictionary."""
        return {
            'alpha': self.alpha,
            'dt': self.dt,
            'dx': self.dx,
            'dy': self.dy,
            'total_time': self.nt * self.dt,
            'grid_size': f'{self.nx} x {self.ny}',
        }

    def initialize_temperature(self):
        """Initialize temperature field."""
        T = np.ones((self.nx, self.ny)) * self.T_ambient

        # Hot region in center (1m x 1m area, 20K higher)
        i_start = int(0.5 / self.dx)
        i_end = int(1.5 / self.dx) + 1
        j_start = int(0.5 / self.dy)
        j_end = int(1.5 / self.dy) + 1

        T[i_start:i_end, j_start:j_end] = self.T_ambient + 20

        return T

    def run_simulation(self, progress_callback=None):
        """
        Run the heat diffusion simulation.

        Args:
            progress_callback: Optional function(progress, stats) called each step
        """
        self._compute_derived_values()

        T = self.initialize_temperature()
        self.T_history = [T.copy()]
        self.time_points = [0.0]
        self.stats_history = [self._compute_stats(T, 0)]

        for n in range(self.nt):
            Tn = T.copy()

            # Update interior points
            for i in range(1, self.nx - 1):
                for j in range(1, self.ny - 1):
                    # Diffusion terms
                    diffusion_x = self.alpha * (Tn[i+1, j] - 2*Tn[i, j] + Tn[i-1, j]) / self.dx**2
                    diffusion_y = self.alpha * (Tn[i, j+1] - 2*Tn[i, j] + Tn[i, j-1]) / self.dy**2

                    # Heat generation term
                    heat_generation = self.q_dot_heater / (self.rho_gas * self.cp_gas)

                    # Convection loss term
                    convection_loss = (self.h_wall * self.P_chamber / self.A_chamber) * \
                                     (Tn[i, j] - self.T_ambient) / (self.rho_gas * self.cp_gas)

                    # Update temperature
                    T[i, j] = Tn[i, j] + self.dt * (diffusion_x + diffusion_y +
                                                    heat_generation - convection_loss)

            # Boundary conditions (Dirichlet - fixed wall temperature)
            T[0, :] = self.T_ambient
            T[self.nx-1, :] = self.T_ambient
            T[:, 0] = self.T_ambient
            T[:, self.ny-1] = self.T_ambient

            # Store results every 5 steps
            if n % 5 == 0:
                current_time = (n + 1) * self.dt
                self.T_history.append(T.copy())
                self.time_points.append(current_time)
                stats = self._compute_stats(T, current_time)
                self.stats_history.append(stats)

                if progress_callback:
                    progress = (n + 1) / self.nt * 100
                    progress_callback(progress, stats)

        return self.T_history, self.time_points

    def _compute_stats(self, T, time):
        """Compute statistics from temperature field."""
        interior = T[1:-1, 1:-1]
        return {
            'time': time,
            'T_max': np.max(T),
            'T_min': np.min(T),
            'T_mean': np.mean(interior),
            'T_center': T[self.nx//2, self.ny//2],
        }

    def get_meshgrid(self):
        """Get X, Y meshgrid for plotting."""
        return np.meshgrid(self.x, self.y)
