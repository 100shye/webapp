"""
Heat Diffusion Simulation Desktop Application
2D Heat Diffusion in Hydrogen Chamber
"""
import matplotlib
matplotlib.use('TkAgg')  # Set backend before importing pyplot

import tkinter as tk
from tkinter import ttk, messagebox
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.figure import Figure
from mpl_toolkits.mplot3d import Axes3D
import threading

from heat_simulation import HeatSimulation


class HeatSimulationApp:
    """Desktop application for heat diffusion simulation."""

    def __init__(self):
        self.root = tk.Tk()
        self.root.title("2D Heat Diffusion Simulation - H2 Chamber")
        self.root.geometry("1300x800")
        self.root.minsize(1100, 700)

        self.simulation = HeatSimulation()
        self.current_frame = 0
        self.is_playing = False
        self.play_job = None

        self._setup_ui()

    def _setup_ui(self):
        """Set up the user interface."""
        # Use PanedWindow for resizable panels
        paned = ttk.PanedWindow(self.root, orient=tk.HORIZONTAL)
        paned.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # Left panel - Controls (with scrollbar)
        left_container = ttk.Frame(paned)

        # Canvas for scrolling
        canvas = tk.Canvas(left_container, width=320, highlightthickness=0)
        scrollbar = ttk.Scrollbar(left_container, orient=tk.VERTICAL, command=canvas.yview)

        left_panel = ttk.Frame(canvas)

        canvas.configure(yscrollcommand=scrollbar.set)

        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        canvas_window = canvas.create_window((0, 0), window=left_panel, anchor="nw")

        def configure_scroll(event):
            canvas.configure(scrollregion=canvas.bbox("all"))
            canvas.itemconfig(canvas_window, width=event.width)

        left_panel.bind("<Configure>", configure_scroll)

        # Right panel - Visualization
        right_panel = ttk.Frame(paned)

        paned.add(left_container, weight=0)
        paned.add(right_panel, weight=1)

        self._setup_controls(left_panel)
        self._setup_visualization(right_panel)

    def _setup_controls(self, parent):
        """Set up control panel."""
        # Add padding frame
        content = ttk.Frame(parent, padding="10")
        content.pack(fill=tk.BOTH, expand=True)

        # Title
        title = ttk.Label(content, text="Simulation Parameters", font=("Arial", 14, "bold"))
        title.pack(pady=(0, 15))

        # Parameters frame
        params_frame = ttk.LabelFrame(content, text="Gas Properties (H2)", padding="10")
        params_frame.pack(fill=tk.X, pady=5)

        self.param_vars = {}

        # Density
        self._add_parameter(params_frame, "rho_gas", "Density (kg/m³):", 0.0898, 0.01, 1.0)
        # Specific heat
        self._add_parameter(params_frame, "cp_gas", "Specific Heat (J/kg·K):", 14300, 1000, 20000)
        # Thermal conductivity
        self._add_parameter(params_frame, "k_gas", "Conductivity (W/m·K):", 0.18, 0.01, 1.0)

        # Heat transfer frame
        heat_frame = ttk.LabelFrame(content, text="Heat Transfer", padding="10")
        heat_frame.pack(fill=tk.X, pady=5)

        self._add_parameter(heat_frame, "q_dot_heater", "Heater Power (W/m³):", 3000, 0, 10000)
        self._add_parameter(heat_frame, "h_wall", "Wall Convection (W/m²·K):", 0.05, 0.01, 1.0)
        self._add_parameter(heat_frame, "T_ambient", "Ambient Temp (K):", 393, 273, 500)

        # Simulation frame
        sim_frame = ttk.LabelFrame(content, text="Simulation Settings", padding="10")
        sim_frame.pack(fill=tk.X, pady=5)

        self._add_parameter(sim_frame, "nx", "Grid X:", 51, 21, 101, is_int=True)
        self._add_parameter(sim_frame, "ny", "Grid Y:", 51, 21, 101, is_int=True)
        self._add_parameter(sim_frame, "nt", "Time Steps:", 100, 50, 500, is_int=True)

        # Run Button - Make it prominent
        btn_frame = ttk.Frame(content)
        btn_frame.pack(fill=tk.X, pady=15)

        self.run_btn = tk.Button(btn_frame, text="▶  RUN SIMULATION", command=self._run_simulation,
                                  font=("Arial", 12, "bold"), bg="#4CAF50", fg="white",
                                  activebackground="#45a049", height=2)
        self.run_btn.pack(fill=tk.X)

        # Progress bar
        self.progress_var = tk.DoubleVar(value=0)
        self.progress_bar = ttk.Progressbar(content, variable=self.progress_var, maximum=100)
        self.progress_bar.pack(fill=tk.X, pady=5)

        self.status_label = ttk.Label(content, text="Ready - Click 'RUN SIMULATION' to start",
                                       foreground="gray")
        self.status_label.pack()

        # Playback controls
        playback_frame = ttk.LabelFrame(content, text="Playback", padding="10")
        playback_frame.pack(fill=tk.X, pady=10)

        btn_row = ttk.Frame(playback_frame)
        btn_row.pack(fill=tk.X)

        self.play_btn = ttk.Button(btn_row, text="▶ Play", command=self._toggle_play, state=tk.DISABLED)
        self.play_btn.pack(side=tk.LEFT, padx=2)

        self.reset_btn = ttk.Button(btn_row, text="⏮ Reset", command=self._reset_frame, state=tk.DISABLED)
        self.reset_btn.pack(side=tk.LEFT, padx=2)

        # Frame slider
        self.frame_var = tk.IntVar(value=0)
        self.frame_slider = tk.Scale(playback_frame, from_=0, to=1, variable=self.frame_var,
                                      orient=tk.HORIZONTAL, command=self._on_slider_change,
                                      showvalue=False, state=tk.DISABLED)
        self.frame_slider.pack(fill=tk.X, pady=5)

        self.frame_label = ttk.Label(playback_frame, text="Frame: 0 / 0")
        self.frame_label.pack()

        # Results display
        results_frame = ttk.LabelFrame(content, text="Results", padding="10")
        results_frame.pack(fill=tk.BOTH, expand=True, pady=5)

        self.results_text = tk.Text(results_frame, height=12, width=35, font=("Courier", 10))
        self.results_text.pack(fill=tk.BOTH, expand=True)
        self.results_text.config(state=tk.DISABLED)

    def _add_parameter(self, parent, name, label, default, min_val, max_val, is_int=False):
        """Add a parameter input field."""
        frame = ttk.Frame(parent)
        frame.pack(fill=tk.X, pady=2)

        ttk.Label(frame, text=label, width=22).pack(side=tk.LEFT)

        var = tk.DoubleVar(value=default) if not is_int else tk.IntVar(value=default)
        self.param_vars[name] = var

        entry = ttk.Entry(frame, textvariable=var, width=10)
        entry.pack(side=tk.RIGHT)

    def _setup_visualization(self, parent):
        """Set up matplotlib visualization."""
        # Create figure with 2D heatmap (more reliable than 3D)
        self.fig, self.ax = plt.subplots(figsize=(8, 6))
        self.fig.set_dpi(100)

        # Colorbar placeholder
        self.colorbar = None

        # Canvas
        self.canvas = FigureCanvasTkAgg(self.fig, master=parent)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

        # Toolbar
        toolbar = NavigationToolbar2Tk(self.canvas, parent)
        toolbar.update()

        # Initial empty plot
        self._draw_empty_plot()

    def _draw_empty_plot(self):
        """Draw empty plot placeholder."""
        self.ax.clear()
        self.ax.set_xlabel("X (m)")
        self.ax.set_ylabel("Y (m)")
        self.ax.set_title("Click 'RUN SIMULATION' to start")
        self.ax.text(0.5, 0.5, "Run simulation to see\ntemperature distribution",
                     ha='center', va='center', transform=self.ax.transAxes,
                     fontsize=14, color='gray')
        self.canvas.draw()

    def _run_simulation(self):
        """Run the simulation."""
        # Update parameters
        try:
            params = {name: var.get() for name, var in self.param_vars.items()}
            self.simulation.set_parameters(**params)
        except Exception as e:
            messagebox.showerror("Error", f"Invalid parameters: {e}")
            return

        # Disable controls
        self.run_btn.config(state=tk.DISABLED, text="Running...")
        self.status_label.config(text="Running simulation...", foreground="blue")
        self.progress_var.set(0)
        self.root.update()

        # Run simulation directly (simpler, more reliable)
        try:
            self.simulation.run_simulation(progress_callback=self._on_progress_direct)
            self._on_simulation_complete()
        except Exception as e:
            self._on_simulation_error(str(e))

    def _on_progress_direct(self, progress, stats):
        """Handle progress update directly."""
        self.progress_var.set(progress)
        self.status_label.config(text=f"Running... {progress:.0f}%")
        self._update_results(stats)
        self.root.update_idletasks()

    def _on_progress(self, progress, stats):
        """Handle progress update."""
        self.root.after(0, lambda: self._update_progress(progress, stats))

    def _update_progress(self, progress, stats):
        """Update progress bar and stats."""
        self.progress_var.set(progress)
        self._update_results(stats)

    def _on_simulation_complete(self):
        """Handle simulation completion."""
        self.run_btn.config(state=tk.NORMAL, text="▶  RUN SIMULATION")
        self.status_label.config(text="Simulation complete!", foreground="green")

        # Enable playback
        self.play_btn.config(state=tk.NORMAL)
        self.reset_btn.config(state=tk.NORMAL)
        self.frame_slider.config(state=tk.NORMAL)

        # Update slider range
        max_frame = len(self.simulation.T_history) - 1
        self.frame_slider.configure(to=max_frame)
        self.frame_var.set(0)

        # Draw first frame
        self._draw_frame(0)

    def _on_simulation_error(self, error):
        """Handle simulation error."""
        self.run_btn.config(state=tk.NORMAL)
        self.status_label.config(text=f"Error: {error}", foreground="red")
        messagebox.showerror("Simulation Error", error)

    def _draw_frame(self, frame_idx):
        """Draw a specific frame."""
        if not self.simulation.T_history:
            return

        frame_idx = max(0, min(frame_idx, len(self.simulation.T_history) - 1))
        self.current_frame = frame_idx

        T = self.simulation.T_history[frame_idx]
        time = self.simulation.time_points[frame_idx]

        self.ax.clear()

        # Remove old colorbar
        if self.colorbar:
            self.colorbar.remove()

        # Plot 2D heatmap
        T_min = self.simulation.T_ambient - 10
        T_max = np.max(self.simulation.T_history[-1]) + 10

        im = self.ax.imshow(T.T, origin='lower', cmap='hot',
                            extent=[0, 2, 0, 2], vmin=T_min, vmax=T_max)

        # Add colorbar
        self.colorbar = self.fig.colorbar(im, ax=self.ax, label='Temperature (K)')

        # Set labels
        self.ax.set_xlabel("X (m)")
        self.ax.set_ylabel("Y (m)")
        self.ax.set_title(f"2D Heat Diffusion in H2 Chamber (Time: {time:.4f} s)")

        self.fig.tight_layout()
        self.canvas.draw()
        self.root.update()

        # Update frame label
        max_frame = len(self.simulation.T_history) - 1
        self.frame_label.config(text=f"Frame: {frame_idx} / {max_frame}")

        # Update results
        if frame_idx < len(self.simulation.stats_history):
            self._update_results(self.simulation.stats_history[frame_idx])

    def _update_results(self, stats):
        """Update results text display."""
        self.results_text.config(state=tk.NORMAL)
        self.results_text.delete(1.0, tk.END)

        info = self.simulation.get_info()

        text = f"""=== Simulation Info ===
Grid: {info['grid_size']}
dx: {info['dx']:.4f} m
dt: {info['dt']:.4e} s
Alpha: {info['alpha']:.4e} m²/s

=== Current State ===
Time: {stats['time']:.4f} s
T_max: {stats['T_max']:.2f} K
T_min: {stats['T_min']:.2f} K
T_mean: {stats['T_mean']:.2f} K
T_center: {stats['T_center']:.2f} K

=== Temperature (°C) ===
T_max: {stats['T_max'] - 273.15:.2f} °C
T_min: {stats['T_min'] - 273.15:.2f} °C
T_mean: {stats['T_mean'] - 273.15:.2f} °C
"""
        self.results_text.insert(tk.END, text)
        self.results_text.config(state=tk.DISABLED)

    def _on_slider_change(self, value):
        """Handle slider change."""
        if not self.is_playing:
            frame = int(float(value))
            self._draw_frame(frame)

    def _toggle_play(self):
        """Toggle play/pause."""
        if self.is_playing:
            self.is_playing = False
            self.play_btn.config(text="▶ Play")
            if self.play_job:
                self.root.after_cancel(self.play_job)
        else:
            self.is_playing = True
            self.play_btn.config(text="⏸ Pause")
            self._play_next_frame()

    def _play_next_frame(self):
        """Play next frame in animation."""
        if not self.is_playing:
            return

        next_frame = self.current_frame + 1
        if next_frame >= len(self.simulation.T_history):
            next_frame = 0

        self.frame_var.set(next_frame)
        self._draw_frame(next_frame)

        self.play_job = self.root.after(150, self._play_next_frame)

    def _reset_frame(self):
        """Reset to first frame."""
        self.frame_var.set(0)
        self._draw_frame(0)

    def run(self):
        """Run the application."""
        self.root.mainloop()


def main():
    app = HeatSimulationApp()
    app.run()


if __name__ == "__main__":
    main()
