(function() {
    // Tab switching
    var tabs = document.querySelectorAll('.tab');
    var contents = document.querySelectorAll('.tab-content');
    var rcaInit = false;

    function switchTab(tabName) {
        for (var i = 0; i < tabs.length; i++) {
            tabs[i].classList.remove('active');
        }
        for (var i = 0; i < contents.length; i++) {
            contents[i].classList.remove('active');
        }
        document.getElementById('tab-' + tabName).classList.add('active');
        document.getElementById(tabName).classList.add('active');

        setTimeout(function() {
            window.dispatchEvent(new Event('resize'));
        }, 100);

        if (tabName === 'rca' && !rcaInit) {
            setTimeout(initRCA, 200);
            rcaInit = true;
        }
    }

    document.getElementById('tab-heat').addEventListener('click', function() { switchTab('heat'); });
    document.getElementById('tab-gas').addEventListener('click', function() { switchTab('gas'); });
    document.getElementById('tab-arrhenius').addEventListener('click', function() { switchTab('arrhenius'); });
    document.getElementById('tab-rca').addEventListener('click', function() { switchTab('rca'); });

    // ==================== HEAT SIMULATION ====================
    var heatFrames = [];
    var heatTime = [];
    var heatStats = [];
    var heatCurrent = 0;
    var heatPlaying = false;
    var heatInterval = null;

    document.getElementById('heatBtn').addEventListener('click', function() {
        var btn = document.getElementById('heatBtn');
        btn.disabled = true;
        btn.textContent = 'Running...';
        document.getElementById('heatStatus').textContent = 'Simulating...';

        var params = {
            rho_gas: parseFloat(document.getElementById('h_rho').value),
            cp_gas: parseFloat(document.getElementById('h_cp').value),
            k_gas: parseFloat(document.getElementById('h_k').value),
            q_dot_heater: parseFloat(document.getElementById('h_q').value),
            h_wall: parseFloat(document.getElementById('h_hw').value),
            T_ambient: parseFloat(document.getElementById('h_Ta').value),
            nx: parseInt(document.getElementById('h_nx').value),
            ny: parseInt(document.getElementById('h_ny').value),
            nt: parseInt(document.getElementById('h_nt').value)
        };

        fetch('/simulate/heat', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(params)
        })
        .then(function(res) { return res.json(); })
        .then(function(data) {
            heatFrames = data.frames;
            heatTime = data.time_points;
            heatStats = data.stats;
            document.getElementById('heatSlider').max = heatFrames.length - 1;
            document.getElementById('heatStatus').textContent = 'Complete!';
            btn.disabled = false;
            btn.textContent = 'RUN SIMULATION';
            showHeatFrame(0);
        });
    });

    function showHeatFrame(i) {
        i = parseInt(i);
        heatCurrent = i;
        document.getElementById('heatSlider').value = i;
        document.getElementById('heatFrameInfo').textContent = 'Frame: ' + i + '/' + (heatFrames.length - 1);

        var s = heatStats[i];
        document.getElementById('heatResults').textContent =
            'Time: ' + heatTime[i].toFixed(4) + ' s\n' +
            'T_max: ' + s.T_max.toFixed(1) + ' K (' + (s.T_max - 273.15).toFixed(1) + ' C)\n' +
            'T_min: ' + s.T_min.toFixed(1) + ' K\n' +
            'T_mean: ' + s.T_mean.toFixed(1) + ' K\n' +
            'T_center: ' + s.T_center.toFixed(1) + ' K';

        Plotly.newPlot('heatPlot', [{z: heatFrames[i], type: 'heatmap', colorscale: 'Hot'}], {
            title: 'Heat Diffusion (t=' + heatTime[i].toFixed(3) + 's)',
            xaxis: {title: 'X'}, yaxis: {title: 'Y'},
            paper_bgcolor: '#16213e', plot_bgcolor: '#16213e', font: {color: '#eee'}
        }, {responsive: true});
    }

    document.getElementById('heatSlider').addEventListener('input', function() {
        if (!heatPlaying && heatFrames.length > 0) {
            showHeatFrame(this.value);
        }
    });

    document.getElementById('heatPlayBtn').addEventListener('click', function() {
        if (heatFrames.length === 0) return;
        heatPlaying = !heatPlaying;
        if (heatPlaying) {
            this.textContent = 'Pause';
            heatInterval = setInterval(function() {
                showHeatFrame((heatCurrent + 1) % heatFrames.length);
            }, 200);
        } else {
            this.textContent = 'Play';
            clearInterval(heatInterval);
        }
    });

    document.getElementById('heatResetBtn').addEventListener('click', function() {
        heatPlaying = false;
        document.getElementById('heatPlayBtn').textContent = 'Play';
        if (heatInterval) clearInterval(heatInterval);
        if (heatFrames.length > 0) showHeatFrame(0);
    });

    // ==================== GAS SIMULATION ====================
    var gasData = null;
    var gasCurrent = 0;
    var gasPlaying = false;
    var gasInterval = null;

    document.getElementById('gasBtn').addEventListener('click', function() {
        var btn = document.getElementById('gasBtn');
        btn.disabled = true;
        btn.textContent = 'Running...';

        var params = {
            total_time: parseFloat(document.getElementById('g_time').value),
            frames: 200,
            t_purge_end: parseFloat(document.getElementById('g_purge').value),
            t_ramp_end: parseFloat(document.getElementById('g_ramp').value),
            temp_start: parseFloat(document.getElementById('g_t1').value),
            temp_process: parseFloat(document.getElementById('g_t2').value),
            pressure_start: parseFloat(document.getElementById('g_p1').value),
            pressure_process: parseFloat(document.getElementById('g_p2').value),
            flow_h2: parseFloat(document.getElementById('g_h2').value),
            flow_sih4: parseFloat(document.getElementById('g_sih4').value),
            flow_ph3: parseFloat(document.getElementById('g_ph3').value)
        };

        fetch('/simulate/gas', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(params)
        })
        .then(function(res) { return res.json(); })
        .then(function(data) {
            gasData = data;
            document.getElementById('gasSlider').max = gasData.time.length - 1;
            document.getElementById('gasStatus').textContent = 'Complete!';
            btn.disabled = false;
            btn.textContent = 'RUN SIMULATION';
            showGasFrame(0);
        });
    });

    function showGasFrame(i) {
        i = parseInt(i);
        gasCurrent = i;
        document.getElementById('gasSlider').value = i;
        document.getElementById('gasFrameInfo').textContent = 'Frame: ' + i + '/' + (gasData.time.length - 1);

        var t = gasData.time[i];
        document.getElementById('gasResults').textContent =
            'Time: ' + t.toFixed(1) + ' s\n' +
            'Temp: ' + gasData.temp[i].toFixed(1) + ' C\n' +
            'Pressure: ' + gasData.pressure[i].toFixed(1) + ' Torr\n\n' +
            'H2: ' + gasData.flows.H2[i].toFixed(0) + ' sccm\n' +
            'SiH4: ' + gasData.flows.SiH4[i].toFixed(1) + ' sccm\n' +
            'PH3: ' + gasData.flows.PH3[i].toFixed(1) + ' sccm';

        var layout = {paper_bgcolor: '#16213e', plot_bgcolor: '#16213e', font: {color: '#eee'}, margin: {t: 40, b: 40, l: 50, r: 20}};

        Plotly.newPlot('tempPlot', [{x: gasData.time.slice(0, i+1), y: gasData.temp.slice(0, i+1), type: 'scatter', line: {color: '#e94560'}}],
            Object.assign({}, layout, {title: 'Temperature (C)', xaxis: {title: 'Time (s)'}, yaxis: {range: [gasData.temp[0]*0.9, gasData.temp[gasData.temp.length-1]*1.1]}}), {responsive: true});

        Plotly.newPlot('presPlot', [{x: gasData.time.slice(0, i+1), y: gasData.pressure.slice(0, i+1), type: 'scatter', line: {color: '#4cc9f0'}}],
            Object.assign({}, layout, {title: 'Pressure (Torr)', xaxis: {title: 'Time (s)'}, yaxis: {range: [0, gasData.pressure[gasData.pressure.length-1]*1.2]}}), {responsive: true});

        Plotly.newPlot('flowPlot', [
            {x: gasData.time.slice(0, i+1), y: gasData.flows.H2.slice(0, i+1), name: 'H2', line: {color: 'lightblue'}},
            {x: gasData.time.slice(0, i+1), y: gasData.flows.SiH4.slice(0, i+1), name: 'SiH4', line: {color: 'lightgreen'}},
            {x: gasData.time.slice(0, i+1), y: gasData.flows.PH3.slice(0, i+1), name: 'PH3', line: {color: 'lightcoral'}}
        ], Object.assign({}, layout, {title: 'Gas Flows (sccm)', xaxis: {title: 'Time (s)'}, yaxis: {type: 'log', range: [0, 5]}}), {responsive: true});

        var fracs = gasData.mole_fractions;
        var vals = [];
        var labs = [];
        if (fracs.H2[i] > 1e-6) { vals.push(fracs.H2[i]); labs.push('H2'); }
        if (fracs.SiH4[i] > 1e-6) { vals.push(fracs.SiH4[i]); labs.push('SiH4'); }
        if (fracs.PH3[i] > 1e-6) { vals.push(fracs.PH3[i]); labs.push('PH3'); }
        Plotly.newPlot('piePlot', [{values: vals, labels: labs, type: 'pie', marker: {colors: ['lightblue', 'lightgreen', 'lightcoral']}}],
            Object.assign({}, layout, {title: 'Gas Composition'}), {responsive: true});
    }

    document.getElementById('gasSlider').addEventListener('input', function() {
        if (!gasPlaying && gasData) {
            showGasFrame(this.value);
        }
    });

    document.getElementById('gasPlayBtn').addEventListener('click', function() {
        if (!gasData) return;
        gasPlaying = !gasPlaying;
        if (gasPlaying) {
            this.textContent = 'Pause';
            gasInterval = setInterval(function() {
                showGasFrame((gasCurrent + 1) % gasData.time.length);
            }, 50);
        } else {
            this.textContent = 'Play';
            clearInterval(gasInterval);
        }
    });

    document.getElementById('gasResetBtn').addEventListener('click', function() {
        gasPlaying = false;
        document.getElementById('gasPlayBtn').textContent = 'Play';
        if (gasInterval) clearInterval(gasInterval);
        if (gasData) showGasFrame(0);
    });

    // ==================== ARRHENIUS ====================
    document.getElementById('arrBtn').addEventListener('click', function() {
        var params = {
            Ea_eV: parseFloat(document.getElementById('a_Ea').value),
            temp_min: parseFloat(document.getElementById('a_tmin').value),
            temp_max: parseFloat(document.getElementById('a_tmax').value)
        };

        fetch('/simulate/arrhenius', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(params)
        })
        .then(function(res) { return res.json(); })
        .then(function(data) {
            document.getElementById('arrStatus').textContent = 'Calculated!';
            document.getElementById('arrResults').textContent =
                'Activation Energy: ' + params.Ea_eV + ' eV\n' +
                '(' + data.Ea_J.toFixed(0) + ' J/mol)\n\n' +
                'Relative Rate at:\n' +
                '  400C: ' + data.rates_at[400].toExponential(2) + 'x\n' +
                '  600C: ' + data.rates_at[600].toExponential(2) + 'x\n' +
                '  800C: ' + data.rates_at[800].toExponential(2) + 'x\n' +
                '  1000C: ' + data.rates_at[1000].toExponential(2) + 'x\n\n' +
                '(Normalized to rate at 100C)';

            Plotly.newPlot('arrPlot', [{x: data.temps, y: data.rates, type: 'scatter', line: {color: '#e94560'}}], {
                title: 'Temperature Dependence of Reaction Rate',
                xaxis: {title: 'Temperature (C)'},
                yaxis: {title: 'Normalized Rate', type: 'log'},
                paper_bgcolor: '#16213e', plot_bgcolor: '#16213e', font: {color: '#eee'}
            }, {responsive: true});
        });
    });

    // ==================== ROOT CAUSE ANALYSIS ====================
    var rcaNodes = [
        {id: 'problem', label: 'Film Quality Defect', parent: '', color: '#e94560'},
        {id: 'temp', label: 'Temperature Issues', parent: 'problem', color: '#f39c12'},
        {id: 'gas', label: 'Gas Flow Issues', parent: 'problem', color: '#f39c12'},
        {id: 'pressure', label: 'Pressure Issues', parent: 'problem', color: '#f39c12'},
        {id: 'temp_uniformity', label: 'Non-uniform Heating', parent: 'temp', color: '#3498db'},
        {id: 'temp_control', label: 'Temperature Control', parent: 'temp', color: '#3498db'},
        {id: 'flow_rate', label: 'Incorrect Flow', parent: 'gas', color: '#3498db'},
        {id: 'gas_purity', label: 'Gas Impurity', parent: 'gas', color: '#3498db'},
        {id: 'pressure_low', label: 'Low Pressure', parent: 'pressure', color: '#3498db'},
        {id: 'heater_degradation', label: 'Heater Degradation', parent: 'temp_uniformity', color: '#2ecc71'},
        {id: 'mfc_drift', label: 'MFC Calibration', parent: 'flow_rate', color: '#2ecc71'},
        {id: 'pump_issue', label: 'Vacuum Pump Issue', parent: 'pressure_low', color: '#2ecc71'}
    ];

    var rcaNodeData = {
        'problem': {desc: 'Main quality issue', data: [{p: 'Defect Rate', v: '3.2%', s: 'High', a: 'Investigate'}]},
        'temp': {desc: 'Temperature issues', data: [{p: 'Setpoint', v: '800C', s: 'OK', a: 'None'}, {p: 'Actual', v: '795C', s: 'Low', a: 'Calibrate'}]},
        'gas': {desc: 'Gas delivery issues', data: [{p: 'H2 Flow', v: '20000 sccm', s: 'OK', a: 'None'}, {p: 'SiH4 Flow', v: '95 sccm', s: 'Low', a: 'Check MFC'}]},
        'pressure': {desc: 'Pressure control issues', data: [{p: 'Setpoint', v: '100 Torr', s: 'OK', a: 'None'}, {p: 'Actual', v: '97 Torr', s: 'Low', a: 'Check pump'}]},
        'heater_degradation': {desc: 'Heater wear detected', data: [{p: 'Heater Age', v: '2500 hrs', s: 'Aging', a: 'Replace'}, {p: 'Power Draw', v: '+15%', s: 'High', a: 'Priority fix'}]},
        'mfc_drift': {desc: 'MFC calibration drift', data: [{p: 'Error', v: '-5%', s: 'Drift', a: 'Recalibrate'}, {p: 'Last Cal', v: '45 days', s: 'Overdue', a: 'Schedule'}]},
        'pump_issue': {desc: 'Pump degradation', data: [{p: 'Base Pressure', v: '5e-3 Torr', s: 'High', a: 'Service'}, {p: 'Hours', v: '8500', s: 'High', a: 'Overhaul'}]}
    };

    function initRCA() {
        var ids = [];
        var labels = [];
        var parents = [];
        var colors = [];
        for (var i = 0; i < rcaNodes.length; i++) {
            ids.push(rcaNodes[i].id);
            labels.push(rcaNodes[i].label);
            parents.push(rcaNodes[i].parent);
            colors.push(rcaNodes[i].color);
        }

        Plotly.newPlot('rcaTree', [{
            type: 'treemap',
            ids: ids,
            labels: labels,
            parents: parents,
            marker: {colors: colors},
            textfont: {size: 14, color: '#fff'}
        }], {
            margin: {t: 30, b: 10, l: 10, r: 10},
            paper_bgcolor: '#16213e',
            font: {color: '#eee'}
        }, {responsive: true});

        document.getElementById('rcaTree').on('plotly_click', function(data) {
            var nodeId = data.points[0].id;
            selectNode(nodeId);
        });
    }

    function selectNode(nodeId) {
        var node = null;
        for (var i = 0; i < rcaNodes.length; i++) {
            if (rcaNodes[i].id === nodeId) {
                node = rcaNodes[i];
                break;
            }
        }
        if (!node) return;

        document.getElementById('selectedNode').innerHTML = '<span style="color:' + node.color + ';font-weight:bold;">' + node.label + '</span>';

        var info = rcaNodeData[nodeId] || {desc: 'No data', data: []};
        document.getElementById('nodeDetails').textContent = info.desc;

        var html = '';
        for (var j = 0; j < info.data.length; j++) {
            var r = info.data[j];
            html += '<tr style="border-bottom:1px solid #0f3460;"><td style="padding:10px;">' + r.p + '</td><td style="padding:10px;font-weight:bold;">' + r.v + '</td><td style="padding:10px;">' + r.s + '</td><td style="padding:10px;color:#3498db;">' + r.a + '</td></tr>';
        }
        document.getElementById('rcaTableBody').innerHTML = html || '<tr><td colspan="4" style="padding:20px;text-align:center;">No data</td></tr>';
    }

    // ==================== INIT ====================
    Plotly.newPlot('heatPlot', [], {title: 'Click RUN to start', paper_bgcolor: '#16213e', font: {color: '#eee'}}, {responsive: true});
    Plotly.newPlot('arrPlot', [], {title: 'Click CALCULATE to start', paper_bgcolor: '#16213e', font: {color: '#eee'}}, {responsive: true});
})();
