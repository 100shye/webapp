"""
Heat Diffusion & Gas Reaction Simulation - FastAPI Web Application
"""
from fastapi import FastAPI
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import numpy as np
from pathlib import Path
from heat_simulation import HeatSimulation

app = FastAPI(title="Thermodynamic Simulation")

# Get the directory where this file is located
BASE_DIR = Path(__file__).resolve().parent

# Mount static files
app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")

simulation = HeatSimulation()


class HeatParams(BaseModel):
    rho_gas: float = 0.0898
    cp_gas: float = 14300
    k_gas: float = 0.18
    q_dot_heater: float = 3000
    h_wall: float = 0.05
    T_ambient: float = 393
    nx: int = 51
    ny: int = 51
    nt: int = 100


class GasReactionParams(BaseModel):
    total_time: float = 100
    frames: int = 200
    t_purge_end: float = 10
    t_ramp_end: float = 60
    temp_start: float = 300
    temp_process: float = 800
    pressure_start: float = 20
    pressure_process: float = 100
    flow_h2: float = 20000
    flow_sih4: float = 100
    flow_ph3: float = 50


class ArrheniusParams(BaseModel):
    Ea_eV: float = 1.6
    temp_min: float = 100
    temp_max: float = 1000


@app.get("/", response_class=HTMLResponse)
async def home():
    """Serve the main HTML page."""
    html_path = BASE_DIR / "templates" / "index.html"
    with open(html_path, "r") as f:
        return f.read()


@app.post("/simulate/heat")
async def simulate_heat(params: HeatParams):
    """Run heat diffusion simulation."""
    simulation.set_parameters(**params.dict())
    simulation.run_simulation()
    return {
        "frames": [T.tolist() for T in simulation.T_history],
        "time_points": simulation.time_points,
        "stats": simulation.stats_history
    }


@app.post("/simulate/gas")
async def simulate_gas(params: GasReactionParams):
    """Run epitaxy chamber gas reaction simulation."""
    t_array = np.linspace(0, params.total_time, params.frames)
    temp = np.zeros(params.frames)
    pressure = np.zeros(params.frames)
    flows = {'H2': np.zeros(params.frames), 'SiH4': np.zeros(params.frames), 'PH3': np.zeros(params.frames)}

    for i, t in enumerate(t_array):
        if t <= params.t_purge_end:
            progress = 0
        elif t <= params.t_ramp_end:
            progress = (t - params.t_purge_end) / (params.t_ramp_end - params.t_purge_end)
        else:
            progress = 1

        temp[i] = params.temp_start + (params.temp_process - params.temp_start) * progress
        pressure[i] = params.pressure_start + (params.pressure_process - params.pressure_start) * progress
        flows['H2'][i] = params.flow_h2
        flows['SiH4'][i] = params.flow_sih4 * progress
        flows['PH3'][i] = params.flow_ph3 * progress

    total_flow = flows['H2'] + flows['SiH4'] + flows['PH3']
    total_flow[total_flow == 0] = 1
    mole_fractions = {gas: (flows[gas] / total_flow).tolist() for gas in flows}

    return {
        "time": t_array.tolist(),
        "temp": temp.tolist(),
        "pressure": pressure.tolist(),
        "flows": {gas: flows[gas].tolist() for gas in flows},
        "mole_fractions": mole_fractions
    }


@app.post("/simulate/arrhenius")
async def simulate_arrhenius(params: ArrheniusParams):
    """Calculate Arrhenius reaction rate vs temperature."""
    R = 8.314
    Ea_J = params.Ea_eV * 96485
    temps = np.linspace(params.temp_min, params.temp_max, 500)
    temps_K = temps + 273.15
    ref_rate = np.exp(-Ea_J / (R * (params.temp_min + 273.15)))
    rates = np.exp(-Ea_J / (R * temps_K)) / ref_rate

    rates_at = {}
    for T in [400, 600, 800, 1000]:
        if params.temp_min <= T <= params.temp_max:
            rate = np.exp(-Ea_J / (R * (T + 273.15))) / ref_rate
            rates_at[T] = float(rate)

    return {
        "temps": temps.tolist(),
        "rates": rates.tolist(),
        "Ea_J": Ea_J,
        "rates_at": rates_at
    }


if __name__ == "__main__":
    import uvicorn
    print("\n" + "="*50)
    print("Thermodynamic Simulation Server")
    print("="*50)
    print("\nOpen browser: http://localhost:8000")
    print("\nProject structure:")
    print("  - templates/index.html  (HTML template)")
    print("  - static/app.js         (JavaScript)")
    print("  - web_app.py            (FastAPI server)")
    print("  - heat_simulation.py    (Simulation engine)")
    print("\n" + "="*50 + "\n")
    uvicorn.run(app, host="0.0.0.0", port=8000)
