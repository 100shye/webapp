declare const Plotly: any;

document.addEventListener('DOMContentLoaded', async () => {
  const res = await fetch('/api/products');
  const products = await res.json();
  const tbody = document.querySelector('#productTable tbody') as HTMLTableSectionElement;

  // Keep a map for quick lookup when plotting
  const productsMap = new Map<number, any>();

  products.forEach((p: any) => {
    productsMap.set(p.id, p);
    const tr = document.createElement('tr');
    tr.dataset.productId = String(p.id);
    tr.innerHTML = `<td>${p.id}</td><td>${p.name}</td><td>${p.start_time}</td><td>${p.duration_s}</td>`;
    tr.addEventListener('click', () => onToggleRow(tr, p));
    tbody.appendChild(tr);
  });

  const plotBtn = document.getElementById('plotBtn') as HTMLButtonElement;
  plotBtn.addEventListener('click', () => onPlotClick(productsMap));
});

// Support multi-selection
const selectedIds = new Set<number>();
function onToggleRow(tr: HTMLTableRowElement, product: any) {
  const id = product.id;
  if (selectedIds.has(id)) {
    selectedIds.delete(id);
    tr.classList.remove('selected');
  } else {
    selectedIds.add(id);
    tr.classList.add('selected');
  }
}

async function onPlotClick(productsMap: Map<number, any>) {
  if (selectedIds.size === 0) {
    alert('Select one or more products first');
    return;
  }

  const sensor = (document.getElementById('sensorSelect') as HTMLSelectElement).value;

  // Fetch all selected series in parallel
  const fetches = Array.from(selectedIds).map(async (id) => {
    const url = `/api/products/${id}/sensors?sensor=${encodeURIComponent(sensor)}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error(`Failed to fetch ${id}`);
    const data = await res.json();
    const meta = productsMap.get(Number(id));
    return { id, meta, data };
  });

  let results;
  try {
    results = await Promise.all(fetches);
  } catch (err) {
    alert('Error fetching series: ' + String(err));
    return;
  }

  const traces = results.map((r) => ({ x: r.data.times, y: r.data.values, name: `${r.meta.name} (id:${r.id})`, mode: 'lines' }));

  const layout = { title: `Sensor: ${sensor}`, xaxis: { title: 'Seconds' }, yaxis: { title: sensor } };
  Plotly.newPlot('plot', traces, layout, { responsive: true });
}
