from eda import data


def test_product_count():
    products = data.get_products()
    assert len(products) == 200


def test_sensor_length():
    t, y = data.get_sensor_series(0, 'heater_temp')
    assert len(t) == 600
    assert len(y) == 600


def test_unknown_sensor():
    try:
        data.get_sensor_series(0, 'nope')
        assert False, "Expected KeyError"
    except KeyError:
        assert True
