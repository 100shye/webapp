from fastapi import FastAPI, Request, HTTPException
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel
import os

from .data import get_products, get_sensor_series

app = FastAPI(title="EDA Demo")

templates = Jinja2Templates(directory=os.path.join(os.path.dirname(__file__), "templates"))
app.mount("/static", StaticFiles(directory=os.path.join(os.path.dirname(__file__), "static")), name="static")


@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    import time
    return templates.TemplateResponse("index.html", {"request": request, "now": int(time.time())})


@app.get("/api/products")
async def api_products():
    return JSONResponse(get_products())


@app.get("/api/products/{product_id}/sensors")
async def api_product_sensor(product_id: int, sensor: str):
    try:
        t, y = get_sensor_series(product_id, sensor)
    except KeyError:
        raise HTTPException(status_code=400, detail="Unknown sensor")
    return {"times": t, "values": y, "sensor": sensor}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8005)
