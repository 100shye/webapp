#!/usr/bin/env python3
"""Fetch sensor series for selected product IDs and write a Plotly HTML file."""
import sys
import json
from urllib.request import urlopen, Request
from urllib.parse import urlencode
from pathlib import Path

API_BASE = "http://127.0.0.1:8005"
OUT_DIR = Path(__file__).resolve().parents[1] / "output"
OUT_DIR.mkdir(parents=True, exist_ok=True)


def fetch_series(product_id: int, sensor: str = "heater_temp"):
    q = urlencode({"sensor": sensor})
    url = f"{API_BASE}/api/products/{product_id}/sensors?{q}"
    req = Request(url, headers={"Accept": "application/json"})
    with urlopen(req, timeout=10) as r:
        return json.load(r)


HTML_TMPL = """<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <script src="https://cdn.plot.ly/plotly-2.20.0.min.js"></script>
  <title>Selected Series Plot</title>
</head>
<body>
  <h2>Selected Series</h2>
  <div id="plot" style="width:100%;height:620px;"></div>
  <script>
    const traces = {traces};
    Plotly.newPlot('plot', traces, {{title: 'Selected Products - Sensor: {sensor}', xaxis:{{title:'Seconds'}}, yaxis:{{title:'Value'}}}});
  </script>
</body>
</html>
"""


def main(ids, sensor='heater_temp'):
    traces = []
    saved = {"sensor": sensor, "series": []}
    for pid in ids:
        obj = fetch_series(pid, sensor)
        traces.append({"x": obj["times"], "y": obj["values"], "name": f"id:{pid}"})
        saved["series"].append({"id": pid, "times": obj["times"], "values": obj["values"]})

    html = HTML_TMPL.format(traces=json.dumps(traces), sensor=sensor)
    out_html = OUT_DIR / "selected_plot.html"
    out_json = OUT_DIR / "selected_series.json"

    out_html.write_text(html, encoding='utf-8')
    out_json.write_text(json.dumps(saved), encoding='utf-8')
    print(f"Wrote HTML: {out_html}")
    print(f"Wrote JSON: {out_json}")


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: generate_plot_html.py <id1,id2,...> [sensor]")
        sys.exit(1)
    ids = [int(x) for x in sys.argv[1].split(',')]
    sensor = sys.argv[2] if len(sys.argv) > 2 else 'heater_temp'
    main(ids, sensor)
