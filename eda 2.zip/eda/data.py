"""Simple in-memory data generator for EDA demo.
Generates a daily list of ~200 products and reproducible sensor time-series.
"""
import numpy as np
from datetime import datetime, timedelta
import random

NUM_PRODUCTS = 200
DURATION_S = 600  # 10 minutes
SENSORS = ["heater_temp", "pressure", "gas_flow"]

random.seed(42)

# Create product list (id, name, start_time)
products = []
base_time = datetime.now().replace(hour=8, minute=0, second=0, microsecond=0)
for i in range(NUM_PRODUCTS):
    name = f"Rcp{random.randint(1,30)}"
    start = base_time + timedelta(seconds=i * (DURATION_S // 2))  # stagger starts
    products.append({"id": i, "name": name, "start_time": start.isoformat(), "duration_s": DURATION_S})


def get_products():
    return products


def _make_timeseries(seed: int, sensor: str):
    rng = np.random.RandomState(seed)
    t = np.arange(DURATION_S)

    if sensor == "heater_temp":
        base = 500 + rng.normal(0, 2, size=DURATION_S)  # base around 500K
        # add ramp and cycles
        ramp = (t / DURATION_S) * 200  # ramp up ~200K over run
        cycle = 10 * np.sin(2 * np.pi * t / 60)  # small oscillation
        y = base + ramp + cycle + rng.normal(0, 0.5, size=DURATION_S)
    elif sensor == "pressure":
        base = 50 + 5 * np.sin(2 * np.pi * t / 300) + rng.normal(0, 0.2, size=DURATION_S)
        y = base
    elif sensor == "gas_flow":
        base = 1000 + 100 * np.exp(-((t - 100) ** 2) / (2 * (200 ** 2))) + rng.normal(0, 5, size=DURATION_S)
        y = base
    else:
        y = rng.normal(size=DURATION_S)

    return t.tolist(), y.tolist()


def get_sensor_series(product_id: int, sensor: str):
    if sensor not in SENSORS:
        raise KeyError(f"Unknown sensor {sensor}")
    # Use product_id and sensor to seed deterministic RNG
    seed = 1000 + product_id * 10 + (hash(sensor) % 997)
    return _make_timeseries(seed, sensor)
