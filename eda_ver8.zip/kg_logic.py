import os
import pandas as pd
import pyarrow.parquet as pq
from itertools import combinations
from datetime import datetime

STORAGE_ROOT = "./storage"

def parse_filename(filename):
    """파일명 파싱 (data_load.py와 동일 로직)"""
    try:
        name_without_ext = filename.replace(".parquet", "")
        parts = name_without_ext.split("_")
        if len(parts) < 3: return None, None, None
        tool = parts[0]
        date_str = parts[1]
        recipe = "_".join(parts[2:])
        date_obj = datetime.strptime(date_str, "%Y-%m-%d").date()
        return tool, date_obj, recipe
    except:
        return None, None, None

def generate_kg_data(process, tools, recipes, start_date_str, end_date_str, threshold=0.5):
    """
    선택된 조건(다중 툴, 기간, 다중 레시피)의 데이터를 모두 모아
    통합 상관관계 그래프 데이터를 생성합니다.
    """
    try:
        s_date = datetime.strptime(start_date_str, "%Y-%m-%d").date()
        e_date = datetime.strptime(end_date_str, "%Y-%m-%d").date()
    except ValueError:
        return None

    # 1. 파일 수집
    files_to_read = []
    for tool in tools:
        tool_dir = os.path.join(STORAGE_ROOT, process, tool)
        if not os.path.exists(tool_dir): continue
        
        for f in os.listdir(tool_dir):
            if f.endswith(".parquet"):
                f_tool, f_date, f_recipe = parse_filename(f)
                if f_tool and f_date:
                    if s_date <= f_date <= e_date and f_recipe in recipes:
                        files_to_read.append(os.path.join(tool_dir, f))

    if not files_to_read:
        return None

    # 2. 데이터 통합 (Concatenate)
    # 각 센서별로 모든 파일의 history를 이어 붙여 긴 시계열을 만듭니다.
    sensor_history_map = {} # { 'sensor_name': [1, 2, 3, ... (전체 기간)] }
    sensor_group_map = {}   # { 'sensor_name': 'group_name' }

    for file_path in files_to_read:
        try:
            df = pq.read_table(file_path).to_pandas()
            for _, row in df.iterrows():
                s_name = row['sensor']
                s_group = row['group']
                # 데이터가 array일 수 있으므로 list로 변환하여 확장
                hist = list(row['history'])
                
                if s_name not in sensor_history_map:
                    sensor_history_map[s_name] = []
                    sensor_group_map[s_name] = s_group
                
                sensor_history_map[s_name].extend(hist)
        except Exception as e:
            print(f"Skipping {file_path}: {e}")
            continue

    if not sensor_history_map:
        return None

    # 3. 상관관계 계산
    # DataFrame 생성 (Rows: Time, Cols: Sensor)
    # 모든 센서의 데이터 길이가 같아야 상관분석이 되는데, 
    # 정상적인 경우라면 파일 단위로 append 했으므로 길이는 같습니다.
    ts_df = pd.DataFrame(sensor_history_map)
    corr_matrix = ts_df.corr()

    # 4. D3용 JSON 변환
    nodes = []
    links = []

    # (1) 그룹 노드
    groups = list(set(sensor_group_map.values()))
    for g in groups:
        nodes.append({"id": g, "group": "group_node", "radius": 25})

    # (2) 센서 노드 및 구조적 링크
    for sensor, group in sensor_group_map.items():
        nodes.append({"id": sensor, "group": "sensor_node", "radius": 12})
        links.append({
            "source": group,
            "target": sensor,
            "type": "structure",
            "value": 1
        })

    # (3) 상관관계 링크
    sensors = list(sensor_group_map.keys())
    for s1, s2 in combinations(sensors, 2):
        if s1 not in corr_matrix.columns or s2 not in corr_matrix.columns:
            continue
            
        corr_val = abs(corr_matrix.loc[s1, s2])
        
        # 임계치 이상일 때만 연결
        if corr_val >= threshold:
            links.append({
                "source": s1,
                "target": s2,
                "type": "correlation",
                "value": round(corr_val, 2)
            })

    return {"nodes": nodes, "links": links}