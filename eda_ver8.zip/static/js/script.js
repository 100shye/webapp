// Color Palette
const COLORS = ['#636EFA', '#EF553B', '#00CC96', '#AB63FA', '#FFA15A', '#19D3F3', '#FF6692', '#B6E880', '#FF97FF', '#FECB52'];

// --- API Interaction Functions ---
function updateTargetToolOptions() {
    console.log("작동?");
    const toolSelect = document.getElementById("tool-select");
    const targetSelect = document.getElementById("target-tool-select");
    
    // 현재 선택된 툴 목록 가져오기
    const selectedTools = Array.from(toolSelect.selectedOptions).map(o => o.value);
    
    // 기존 선택값 기억
    const currentTarget = targetSelect.value;
    
    targetSelect.innerHTML = "";
    
    if (selectedTools.length === 0) {
        targetSelect.innerHTML = "<option disabled selected>Select tools above</option>";
        return;
    }
    
    selectedTools.forEach(tool => {
        const opt = document.createElement("option");
        opt.value = tool;
        opt.innerText = tool;
        targetSelect.appendChild(opt);
    });
    
    // 이전에 선택했던 값이 여전히 유효하면 유지, 아니면 첫번째 것 선택
    if (selectedTools.includes(currentTarget)) {
        targetSelect.value = currentTarget;
    } else {
        targetSelect.selectedIndex = 0;
    }
}

async function updateToolList() {
    const process = document.getElementById("process-select").value;
    const toolSelect = document.getElementById("tool-select");
    toolSelect.innerHTML = "<option>Loading...</option>";
    try {
        const res = await fetch(`/api/tools?process=${process}`);
        const data = await res.json();
        toolSelect.innerHTML = "";
        if(data.tools && data.tools.length) {
            data.tools.forEach(t => {
                const opt = document.createElement("option");
                opt.value = t; opt.innerText = t; toolSelect.appendChild(opt);
            });
        } else toolSelect.innerHTML = "<option disabled>No tools found</option>";
        updateRecipeList();
    } catch(e) { console.error(e); }
}

async function updateRecipeList() {
    const process = document.getElementById("process-select").value;
    const tools = Array.from(document.getElementById("tool-select").selectedOptions).map(o=>o.value);
    const recipeSelect = document.getElementById("recipe-select");
    
    if(!process || tools.length === 0) {
        recipeSelect.innerHTML = "<option disabled>Select Tools first</option>";
        return;
    }
    recipeSelect.innerHTML = "<option>Loading...</option>";
    try {
        const res = await fetch("/api/recipes", {
            method: "POST", headers: {"Content-Type":"application/json"},
            body: JSON.stringify({
                process: process, tools: tools,
                start_date: document.getElementById("start-date").value,
                end_date: document.getElementById("end-date").value
            })
        });
        const data = await res.json();
        recipeSelect.innerHTML = "";
        if(data.recipes && data.recipes.length) {
            data.recipes.forEach(r => {
                const opt = document.createElement("option");
                opt.value = r; opt.innerText = r; recipeSelect.appendChild(opt);
            });
        } else recipeSelect.innerHTML = "<option disabled>No recipes found</option>";
    } catch(e) { console.error(e); }
}

async function loadData() {
    const process = document.getElementById("process-select").value;
    const tools = Array.from(document.getElementById("tool-select").selectedOptions).map(o=>o.value);
    const recipes = Array.from(document.getElementById("recipe-select").selectedOptions).map(o=>o.value);
    const targetTool = document.getElementById("target-tool-select").value; 
    const issueType = document.getElementById("issue-select").value;

    if(!tools.length || !recipes.length) { alert("Select tools and recipes"); return; }
    if(!targetTool) { alert("Select a Target Tool for comparison"); return; }
    
    const btn = document.querySelector(".btn-primary");
    btn.innerText = "Comparing..."; btn.disabled = true;
    
    try {
        const res = await fetch("/api/load", {
            method: "POST", headers: {"Content-Type":"application/json"},
            body: JSON.stringify({
                process: process, tools: tools, recipes: recipes,
                start_date: document.getElementById("start-date").value,
                end_date: document.getElementById("end-date").value,
                target_tool: targetTool,
                issue_type: issueType 
            })
        });
        if(!res.ok) throw new Error((await res.json()).error);
        const treeData = await res.json();
        renderTree(treeData, targetTool); // targetTool 전달
    } catch(e) { alert(e.message); }
    finally { btn.innerText = "Compare Target vs Others"; btn.disabled = false; }
}

// [핵심 수정 함수] renderTree
function renderTree(treeData, targetTool) {
    // 1. 기존 요소 초기화
    d3.select("#tree-wrapper").selectAll("*").remove();
    document.getElementById("list-content").innerHTML = "<div style='color:#999; text-align:center; margin-top:20px;'>Select a node</div>";
    Plotly.purge('plotly-chart');
    document.getElementById("node-summary").style.display = "none"; // 요약 박스 숨김

    const container = document.getElementById("tree-wrapper");
    
    // ==========================================
    // [Zoom Fix 1] 줌 객체를 변수에 저장하여 재사용
    // ==========================================
    const svg = d3.select("#tree-wrapper").append("svg")
        .attr("width", "100%").attr("height", "100%");
        
    const g = svg.append("g");
    
    const zoom = d3.zoom().on("zoom", (e) => {
        g.attr("transform", e.transform);
    });

    svg.call(zoom).on("dblclick.zoom", null);
    
    // 트리 데이터 처리
    const root = d3.hierarchy(treeData, d => d.children);
    const tree = d3.tree().nodeSize([40, 140]);
    const nodes = tree(root);

    // 링크 생성
    const link = g.selectAll(".link").data(nodes.links()).enter().append("path")
        .attr("class", "link").attr("d", d3.linkHorizontal().x(d => d.y).y(d => d.x));

    // 노드 생성
    const node = g.selectAll(".node").data(nodes.descendants()).enter().append("g")
        .attr("class", "node").attr("transform", d => `translate(${d.y},${d.x})`);

    node.append("circle").attr("r", 8)
        .on("click", function(event, d) {
            // --- 스타일 업데이트 ---
            d3.selectAll("circle").classed("selected", false);
            d3.select(this).classed("selected", true);
            const ancestors = new Set(d.ancestors());
            link.classed("highlight", l => ancestors.has(l.target))
                .classed("dimmed", l => !ancestors.has(l.target));

            // ==========================================
            // [Feature] 요약 설명 생성 (Target vs Others)
            // ==========================================
            const summaryBox = document.getElementById("node-summary");
            
            // 센서 노드이고, 데이터가 있는지 확인
            if (d.data.type === "sensor" && d.data.tool_history) {
                const history = d.data.tool_history;
                const targetValues = history[targetTool];
                
                if (targetValues && targetValues.length > 0) {
                    const targetLastVal = targetValues[targetValues.length - 1]; // 타겟 최신값
                    
                    let otherSum = 0;
                    let otherCount = 0;
                    
                    // 나머지 툴 평균 계산
                    Object.keys(history).forEach(tName => {
                        if (tName !== targetTool) {
                            const h = history[tName];
                            if (h && h.length > 0) {
                                otherSum += h[h.length - 1];
                                otherCount++;
                            }
                        }
                    });
                    
                    if (otherCount > 0) {
                        const avgOthers = otherSum / otherCount;
                        const diff = targetLastVal - avgOthers;
                        const absDiff = Math.abs(diff).toFixed(2);
                        const isHigher = diff > 0;
                        
                        const statusText = isHigher ? "높습니다(High)" : "낮습니다(Low)";
                        const colorStyle = isHigher ? "color:#d32f2f;" : "color:#1976d2;"; // 빨강 or 파랑
                        
                        summaryBox.innerHTML = `
                            <strong>${d.data.name}</strong> 센서는 
                            Target Tool (<b>${targetTool}</b>)이 나머지 Tool 평균보다 
                            <span class="summary-highlight" style="${colorStyle}">${absDiff}</span> 점 
                            <span style="${colorStyle} font-weight:bold;">${statusText}</span>.
                        `;
                        summaryBox.style.display = "block";
                    } else {
                        summaryBox.innerHTML = "비교할 다른 Tool 데이터가 부족합니다.";
                        summaryBox.style.display = "block";
                    }
                } else {
                    summaryBox.style.display = "none";
                }
            } else {
                summaryBox.style.display = "none"; // 그룹 노드는 숨김
            }
            // ==========================================

            // 차트 그리기
            if (d.data.chart_config) {
                document.getElementById("placeholder").style.display = "none";
                // Plotly 설정 (drawClientSideChart 함수를 쓴다면 아래 대신 호출)
                drawClientSideChart(d.data.name, d.data.tool_history, targetTool);
            } else {
                Plotly.purge('plotly-chart');
                document.getElementById("placeholder").style.display = "block";
            }

            // 리스트 업데이트 로직 (기존 코드 유지)
            updateRelatedList(d.data, targetTool); 

            event.stopPropagation();
        });

    node.append("text").attr("dy", ".35em").attr("x", d => d.children ? -12 : 12)
        .style("text-anchor", d => d.children ? "end" : "start").text(d => d.data.name);
        
    // 라벨(Score) 그리기 로직 (기존 코드 유지)
    // ... (생략: 기존 코드 그대로 사용) ...

    // ==========================================
    // [Zoom Fix 2] 저장해둔 zoom 객체를 사용하여 초기 위치 이동
    // ==========================================
    // translate(40, height/2) : 왼쪽 여백 40, 수직 중앙 정렬
    svg.call(zoom.transform, d3.zoomIdentity.translate(40, container.clientHeight / 2));
}

// (Helper: 리스트 업데이트 함수 분리 - 기존 로직과 동일)
function updateRelatedList(data, targetTool) {
    const listContent = document.getElementById("list-content");
    const listHeader = document.getElementById("list-header");
    listContent.innerHTML = "";
    
    if (data.related_sensors && data.related_sensors.length > 0) {
        listHeader.innerHTML = `${data.name}<br><small style='font-weight:normal; color:#d32f2f;'>Sorted by Diff (Target: ${targetTool})</small>`;
        data.related_sensors.forEach(sensor => {
            const item = document.createElement("div");
            item.className = "sensor-item";
            const diffVal = sensor.diff_value !== undefined ? Math.round(sensor.diff_value * 10) / 10 : 0;
            const diffColor = diffVal > 10 ? "#d32f2f" : "#666";
            const diffStyle = diffVal > 10 ? "font-weight:bold;" : "";
            
            item.innerHTML = `<span>${sensor.name}</span> <span style="color:${diffColor}; ${diffStyle} font-size:0.85em">Diff: ${diffVal}</span>`;
            item.onclick = () => {
                document.querySelectorAll(".sensor-item").forEach(el => el.classList.remove("active"));
                item.classList.add("active");
                drawClientSideChart(sensor.name, sensor.tool_history, targetTool);
                
                // [선택 사항] 리스트 클릭 시에도 요약 박스를 갱신하고 싶다면 여기서 로직 추가 필요
            };
            listContent.appendChild(item);
        });
    } else {
        listHeader.innerText = "Related Sensors";
        listContent.innerHTML = "<div style='color:#999; text-align:center; margin-top:20px;'>No related sensors</div>";
    }
}

// [핵심 수정] 안전한 클라이언트 사이드 차트 그리기
function drawClientSideChart(name, toolHistoryDict, targetTool) {
    // 1. 데이터 유효성 검사 (null/undefined/not object 일 경우 차단)
    if (!toolHistoryDict || typeof toolHistoryDict !== 'object') {
        console.warn(`[Chart Error] Data missing for: ${name}`);
        Plotly.purge('plotly-chart');
        const ph = document.getElementById("placeholder");
        if(ph) {
            ph.innerText = "No chart data available";
            ph.style.display = "block";
        }
        return;
    }

    const traces = [];
    const tools = Object.keys(toolHistoryDict).sort();
    
    // 색상 팔레트
    const PALETTE = ['#636EFA', '#EF553B', '#00CC96', '#AB63FA', '#FFA15A', '#19D3F3'];

    tools.forEach((tool, index) => {
        let color, width, opacity;
        
        if (tool === targetTool) {
            color = '#d32f2f'; // Target Red
            width = 4;
            opacity = 1.0;
        } else {
            color = PALETTE[index % PALETTE.length];
            if(color === '#d32f2f') color = '#999'; // 빨간색 겹침 방지
            width = 2;
            opacity = 0.5;
        }

        // Y값 데이터 가져오기 (배열인지 확인)
        const yData = Array.isArray(toolHistoryDict[tool]) ? toolHistoryDict[tool] : [];

        traces.push({
            y: yData,
            mode: 'lines+markers',
            name: tool,
            line: {color: color, width: width, shape: 'spline'},
            marker: {size: 6, color: 'white', line: {width: 2, color: color}},
            opacity: opacity
        });
    });

    const layout = {
        title: {text: `${name}`, font: {size: 18, color: '#333'}},
        xaxis: {title: 'Time', showgrid: true, gridcolor: '#eee'},
        yaxis: {title: 'Value', showgrid: true, gridcolor: '#eee'},
        paper_bgcolor: 'rgba(0,0,0,0)', plot_bgcolor: 'rgba(0,0,0,0)',
        margin: {l: 40, r: 20, t: 50, b: 40}, 
        showlegend: true,
        legend: { orientation: "h", yanchor: "bottom", y: 1.02, xanchor: "right", x: 1 }
    };
    
    document.getElementById("placeholder").style.display = "none";
    Plotly.newPlot('plotly-chart', traces, layout, {responsive: true});
}