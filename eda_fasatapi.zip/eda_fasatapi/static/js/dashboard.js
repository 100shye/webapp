// 전역 변수 설정
let svg, g, link, node, zoom, root, tree;
const container = document.getElementById("tree-wrapper");
let width = container.clientWidth;
let height = container.clientHeight;

// 초기 실행
document.addEventListener("DOMContentLoaded", async () => {
    initD3();
    await loadTreeData();
});

function initD3() {
    zoom = d3.zoom().on("zoom", (e) => g.attr("transform", e.transform));
    svg = d3.select("#tree-wrapper").append("svg")
        .attr("width", "100%").attr("height", "100%")
        .call(zoom)
        .on("dblclick.zoom", null);
    g = svg.append("g");
}

// 1. 트리 데이터 API 호출 및 렌더링
async function loadTreeData() {
    try {
        const response = await fetch('/api/tree');
        const treeData = await response.json();
        
        document.getElementById("tree-loading").style.display = "none";
        renderTree(treeData);
    } catch (error) {
        console.error("Failed to load tree:", error);
        document.getElementById("tree-loading").innerText = "Error loading tree.";
    }
}

function renderTree(data) {
    root = d3.hierarchy(data, d => d.children);
    tree = d3.tree().nodeSize([50, 160]);
    const nodes = tree(root);

    // Links
    link = g.selectAll(".link")
        .data(nodes.links())
        .enter().append("path")
        .attr("class", "link")
        .attr("d", d3.linkHorizontal().x(d => d.y).y(d => d.x));

    // Nodes
    node = g.selectAll(".node")
        .data(nodes.descendants())
        .enter().append("g")
        .attr("class", "node")
        .attr("transform", d => "translate(" + d.y + "," + d.x + ")");

    node.append("circle")
        .attr("r", 10)
        .on("click", handleNodeClick);

    node.append("text")
        .attr("dy", ".35em")
        .attr("x", d => d.children ? -15 : 15)
        .style("text-anchor", d => d.children ? "end" : "start")
        .text(d => d.data.name);
        
    // 초기 뷰 조정
    resetView();
}

// 2. 노드 클릭 핸들러 (상세 데이터 API 호출)
async function handleNodeClick(event, d) {
    event.stopPropagation();
    
    // UI 초기화 및 하이라이트
    d3.selectAll("circle").classed("selected", false);
    d3.select(this).classed("selected", true);
    
    const ancestors = new Set(d.ancestors());
    link.classed("highlight", l => ancestors.has(l.target))
        .classed("dimmed", l => !ancestors.has(l.target));

    // 센서 타입이 아니면 리턴
    if (d.data.type !== 'sensor') {
        clearDetailView("Select a sensor node");
        return;
    }

    // 로딩 표시
    document.getElementById("list-loading").style.display = "flex";
    
    try {
        // API 호출: 상세 데이터(40개 연관 센서) 가져오기
        const response = await fetch(`/api/sensor/${d.data.name}`);
        const detailData = await response.json();
        
        document.getElementById("list-loading").style.display = "none";
        
        // 메인 차트 그리기
        drawChart(detailData.sensor_name, detailData.main_history, '#d32f2f');
        
        // 연관 리스트 그리기
        renderRelatedList(detailData.sensor_name, detailData.related_sensors);
        
        // 노드 위 값 표시 (Bubble)
        showValueBubble(this, detailData.current_value);

    } catch (error) {
        console.error("Error fetching details:", error);
        document.getElementById("list-loading").style.display = "none";
    }
}

// 리스트 렌더링
function renderRelatedList(mainName, sensors) {
    const listContent = document.getElementById("list-content");
    const listHeader = document.getElementById("list-header");
    
    listHeader.innerText = `Related: ${mainName} (${sensors.length})`;
    listContent.innerHTML = "";

    sensors.forEach(sensor => {
        const item = document.createElement("div");
        item.className = "sensor-item";
        item.innerHTML = `<span>${sensor.name}</span> <span class="sensor-val">${sensor.value}</span>`;
        
        item.onclick = () => {
            // 리스트 아이템 활성화
            document.querySelectorAll(".sensor-item").forEach(el => el.classList.remove("active"));
            item.classList.add("active");
            // 차트 업데이트
            drawChart(sensor.name, sensor.history, '#1565c0');
        };
        listContent.appendChild(item);
    });
}

// 차트 그리기
function drawChart(name, yValues, color) {
    document.getElementById("placeholder").style.display = "none";
    const trace = {
        y: yValues,
        mode: 'lines+markers',
        name: name,
        line: {color: color, width: 3, shape: 'spline'},
        marker: {size: 8, color: 'white', line: {width: 2, color: color}}
    };
    
    const layout = {
        title: {text: `${name} Trend`, font: {size: 18, color: '#333'}},
        xaxis: {title: 'Time Step', showgrid: true, gridcolor: '#eee'},
        yaxis: {title: 'Value', showgrid: true, gridcolor: '#eee'},
        paper_bgcolor: 'rgba(0,0,0,0)',
        plot_bgcolor: 'rgba(0,0,0,0)',
        margin: {l: 40, r: 20, t: 50, b: 40},
        showlegend: false
    };
    
    Plotly.newPlot('plotly-chart', [trace], layout, {responsive: true});
}

// 노드 위 값 표시 (Bubble)
function showValueBubble(nodeElement, value) {
    d3.selectAll(".value-label-group").remove();
    
    const parentGroup = d3.select(nodeElement.parentNode);
    const labelGroup = parentGroup.append("g")
        .attr("class", "value-label-group")
        .attr("transform", "translate(0, -25)");
    
    labelGroup.append("rect")
        .attr("class", "value-label-bg")
        .attr("x", -25).attr("y", -10).attr("width", 50).attr("height", 20).attr("rx", 5);
    
    labelGroup.append("text")
        .attr("class", "value-label-text")
        .attr("x", 0).attr("y", 4).attr("text-anchor", "middle")
        .text(value);
}

function clearDetailView(msg) {
    Plotly.purge('plotly-chart');
    document.getElementById("placeholder").style.display = "flex";
    document.getElementById("placeholder").innerText = msg;
    document.getElementById("list-header").innerText = "Related Sensors";
    document.getElementById("list-content").innerHTML = `<div class="empty-msg">${msg}</div>`;
}

window.resetView = function() {
    link.classed("highlight", false).classed("dimmed", false);
    d3.selectAll("circle").classed("selected", false);
    d3.selectAll(".value-label-group").remove();
    clearDetailView("Select a sensor node");
    
    svg.transition().duration(750).call(
        zoom.transform, 
        d3.zoomIdentity.translate(80, height/2)
    );
};