import pandas as pd
import random

# 데이터 시뮬레이션 로직
class SensorService:
    def __init__(self):
        # 기본 데이터 구조 정의
        self.base_sensors = [
            {'name': 'top temp', 'group': 'temp'},
            {'name': 'bottom temp', 'group': 'temp'},
            {'name': 'h2', 'group': 'gas'},
            {'name': 'nf3', 'group': 'gas'},
            {'name': 'pressure', 'group': 'press'},
            {'name': 'throttle valve', 'group': 'press'}
        ]

    def _generate_history(self, base_val=None):
        if base_val is None:
            base_val = random.randint(30, 80)
        return [base_val + random.randint(-5, 5) for _ in range(20)]

    # 1. 초기 트리 구조 데이터 (가볍게)
    def get_tree_structure(self):
        df = pd.DataFrame(self.base_sensors)
        
        # 현재 값만 생성 (History 전체는 제외하여 용량 최적화)
        df['current_value'] = [random.randint(30, 80) for _ in range(len(df))]
        
        groups = df.groupby('group')
        children_list = []

        for group_name, group_df in groups:
            sensors = []
            for _, row in group_df.iterrows():
                sensors.append({
                    "name": row['name'],
                    "value": row['current_value'],
                    "type": "sensor"
                })
            children_list.append({
                "name": group_name,
                "children": sensors,
                "type": "group"
            })

        return {
            "name": "Particle Equipment",
            "children": children_list,
            "type": "root"
        }

    # 2. 특정 센서 클릭 시 상세 데이터 (차트 + 연관 센서 40개)
    def get_sensor_detail(self, sensor_name):
        # 메인 센서 히스토리 생성
        main_history = self._generate_history()
        current_value = main_history[-1]

        # 연관 센서 40개 생성
        related_sensors = []
        for i in range(1, 41):
            rel_name = f"{sensor_name}_sub_{i:02d}"
            rel_history = self._generate_history(base_val=current_value)
            related_sensors.append({
                "name": rel_name,
                "value": rel_history[-1],
                "history": rel_history
            })

        return {
            "sensor_name": sensor_name,
            "main_history": main_history,
            "current_value": current_value,
            "related_sensors": related_sensors
        }

sensor_service = SensorService()