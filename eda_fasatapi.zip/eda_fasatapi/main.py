from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import uvicorn
from services import sensor_service

app = FastAPI()

# 정적 파일 및 템플릿 설정
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# 1. 메인 페이지 렌더링
@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

# 2. 트리 데이터 API (초기 로딩용)
@app.get("/api/tree")
async def get_tree():
    return sensor_service.get_tree_structure()

# 3. 상세 데이터 API (클릭 시 호출용)
@app.get("/api/sensor/{sensor_name}")
async def get_sensor_detail(sensor_name: str):
    return sensor_service.get_sensor_detail(sensor_name)

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)