import os
import json
from typing import List, Dict, Any
import pyarrow.parquet as pq
import pyarrow.dataset as ds

BASE_DIR = os.path.dirname(__file__)
DB_DIR = os.path.join(BASE_DIR, 'database')
SUPPORTED_SENSORS = {'heater_temp', 'pressure', 'gas_flow'}


def _product_path(product_id: int) -> str:
    return os.path.join(DB_DIR, f'product_{product_id}.parquet')


def list_products() -> List[Dict[str, Any]]:
    """Scan the database directory and return product metadata."""
    out = []
    if not os.path.isdir(DB_DIR):
        return out
    for fname in sorted(os.listdir(DB_DIR)):
        if not fname.endswith('.parquet'):
            continue
        path = os.path.join(DB_DIR, fname)
        try:
            tbl = pq.read_table(path, columns=['time'])
            rows = tbl.num_rows
            # approximate duration (last - first)
            times = tbl.column('time').to_pylist()
            duration = None
            if rows >= 2:
                duration = float(times[-1] - times[0])
            pid = int(fname.replace('product_', '').replace('.parquet', ''))
            out.append({'id': pid, 'file': fname, 'rows': rows, 'duration': duration})
        except Exception:
            # skip unreadable files
            continue
    return out


def read_series(product_id: int, sensor: str) -> Dict[str, List[float]]:
    if sensor not in SUPPORTED_SENSORS:
        raise ValueError('unsupported sensor')
    path = _product_path(product_id)
    if not os.path.exists(path):
        raise FileNotFoundError(path)
    tbl = pq.read_table(path, columns=['time', sensor])
    times = tbl.column('time').to_pylist()
    vals = tbl.column(sensor).to_pylist()
    return {'times': times, 'values': vals}


def search_by_sensor_threshold(sensor: str, min_value: float = 0.0, limit: int = 10) -> List[Dict[str, Any]]:
    if sensor not in SUPPORTED_SENSORS:
        raise ValueError('unsupported sensor')
    results = []
    if not os.path.isdir(DB_DIR):
        return results
    # try to use pyarrow.dataset for predicate pushdown
    for fname in sorted(os.listdir(DB_DIR)):
        if not fname.endswith('.parquet'):
            continue
        path = os.path.join(DB_DIR, fname)
        try:
            ds_obj = ds.dataset(path, format='parquet')
            # filter rows where sensor >= min_value
            expr = (ds.field(sensor) >= min_value)
            tbl = ds_obj.to_table(filter=expr, columns=['time', sensor])
            if tbl.num_rows > 0:
                pid = int(fname.replace('product_', '').replace('.parquet', ''))
                results.append({'id': pid, 'file': fname, 'matches': tbl.num_rows})
                if len(results) >= limit:
                    break
        except Exception:
            continue
    return results
