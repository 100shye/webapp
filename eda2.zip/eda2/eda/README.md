# EDA (Exploratory Data App)

A small FastAPI-based Exploratory Data Analysis app that serves per-product Parquet time-series data and a lightweight D3 + Plotly UI for visual inspection.

## Overview

- Data: each product is stored as a Parquet file under `eda/database/` (e.g. `product_0.parquet`).
- Backend: `eda/app.py` exposes a few simple REST endpoints and serves the UI templates.
- Storage: `eda/storage.py` uses PyArrow to read Parquet files and provide efficient predicate filtering.
- Frontend: `eda/templates/index.html` uses D3 to render a sensor hierarchy and Plotly to render time-series when a leaf sensor is clicked.

## Quick start (dev)

1. Create and activate your virtual environment and install deps:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r eda/requirements.txt
pip install httpx
pip install playwright
playwright install
```

2. Run the server:

```bash
uvicorn eda.app:app --host 127.0.0.1 --port 8005
```

3. Open the UI in a browser: `http://127.0.0.1:8005`

## Tests

- Unit/API tests: `pytest tests/test_eda_pyarrow_api.py`
- Static/template tests: `pytest tests/test_static_files.py::test_plotly_included`
- Playwright E2E (UI): `pytest tests/test_ui_interaction.py` (requires Playwright and the browser driver installed via `playwright install`)
