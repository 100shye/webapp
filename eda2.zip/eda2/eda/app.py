import os
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from . import storage

app = FastAPI()
BASE_DIR = os.path.dirname(__file__)
app.mount('/static', StaticFiles(directory=os.path.join(BASE_DIR, 'static')), name='static')
templates = Jinja2Templates(directory=os.path.join(BASE_DIR, 'templates'))


@app.get('/api/products')
async def api_products():
    return storage.list_products()


@app.get('/api/products/{product_id}/sensors')
async def api_product_sensor(product_id: int, sensor: str = 'heater_temp'):
    try:
        data = storage.read_series(product_id, sensor)
        return data
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail='product not found')
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.get('/api/search')
async def api_search(sensor: str, min_value: float = 0.0, limit: int = 10):
    try:
        return storage.search_by_sensor_threshold(sensor, min_value=min_value, limit=limit)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.get('/')
async def home(request: Request):
    return templates.TemplateResponse('index.html', {'request': request})
