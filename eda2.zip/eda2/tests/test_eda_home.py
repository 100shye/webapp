from fastapi.testclient import TestClient
from eda.app import app

client = TestClient(app)


def test_home_returns_html():
    r = client.get('/')
    assert r.status_code == 200
    assert 'Sensor Hierarchy' in r.text
