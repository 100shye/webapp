from fastapi.testclient import TestClient
from eda.app import app

client = TestClient(app)


def test_list_products():
    r = client.get('/api/products')
    assert r.status_code == 200
    data = r.json()
    assert isinstance(data, list)
    # there should be product files generated earlier
    assert len(data) >= 1


def test_read_series():
    r = client.get('/api/products/0/sensors?sensor=gas_flow')
    assert r.status_code == 200
    js = r.json()
    assert 'times' in js and 'values' in js
    assert len(js['times']) == len(js['values'])
    assert len(js['times']) > 0


def test_search_by_threshold():
    r = client.get('/api/search?sensor=gas_flow&min_value=0')
    assert r.status_code == 200
    js = r.json()
    assert isinstance(js, list)
