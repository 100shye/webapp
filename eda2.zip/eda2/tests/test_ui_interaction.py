from playwright.sync_api import sync_playwright


def test_click_sensor_plots():
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page()
        page.goto('http://127.0.0.1:8005', wait_until='networkidle')
        # wait for product select element
        page.wait_for_selector('#productSelect', timeout=5000)
        # wait until options are populated (timeout loop)
        import time
        max_t = 5.0
        t0 = time.time()
        while time.time() - t0 < max_t:
            if page.locator('#productSelect option').count() > 0:
                break
            time.sleep(0.05)
        assert page.locator('#productSelect option').count() > 0
        # select first product
        first_val = page.locator('#productSelect option').nth(0).get_attribute('value')
        page.select_option('#productSelect', first_val)
        # Find the first text element with innerText 'h2' and dispatch click event
        texts = page.locator('#tree-container svg text')
        found = False
        for i in range(texts.count()):
            txt = texts.nth(i).evaluate('el => el.textContent')
            if txt == 'h2':
                # dispatch a mouse event on the element
                texts.nth(i).evaluate("el => el.dispatchEvent(new MouseEvent('click', {bubbles:true}))")
                found = True
                break
        assert found, 'no h2 node found'
        # wait for the plot to be rendered by Plotly
        page.wait_for_function("() => document.querySelector('#plot') && document.querySelector('#plot').children.length > 0", timeout=7000)
        # ensure plot info shows plotted
        info = page.locator('#plot-info').inner_text()
        assert 'Plotted' in info
        browser.close()
