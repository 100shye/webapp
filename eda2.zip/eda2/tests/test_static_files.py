from fastapi.testclient import TestClient
from eda.app import app

client = TestClient(app)


def test_d3_served():
    r = client.get("/static/d3.v7.min.js")
    assert r.status_code == 200
    assert "d3" in r.text[:100].lower()


def test_plotly_included():
    r = client.get("/")
    assert r.status_code == 200
    text = r.text.lower()
    # ensure Plotly script tag points to the vendored local file
    assert '/static/plotly.min.js' in text or 'plotly.min.js' in text


def test_plotly_served_locally():
    r = client.get('/static/plotly.min.js')
    assert r.status_code == 200
    # the shim exposes the global name Plotly; check file contains it
    assert 'plotly' in r.text.lower()
