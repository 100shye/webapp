declare const Plotly: any;

document.addEventListener('DOMContentLoaded', async () => {
  const res = await fetch('/api/products');
  const products = await res.json();
  const tbody = document.querySelector('#productTable tbody') as HTMLTableSectionElement;

  products.forEach((p: any) => {
    const tr = document.createElement('tr');
    tr.dataset.productId = p.id;
    tr.innerHTML = `<td>${p.id}</td><td>${p.name}</td><td>${p.start_time}</td><td>${p.duration_s}</td>`;
    tr.addEventListener('click', () => onSelectRow(tr, p));
    tbody.appendChild(tr);
  });

  const plotBtn = document.getElementById('plotBtn') as HTMLButtonElement;
  plotBtn.addEventListener('click', onPlotClick);
});

let selectedProduct: any = null;
function onSelectRow(tr: HTMLTableRowElement, product: any) {
  // highlight
  document.querySelectorAll('#productTable tr').forEach(r => r.classList.remove('selected'));
  tr.classList.add('selected');
  selectedProduct = product;
}

async function onPlotClick() {
  if (!selectedProduct) {
    alert('Select a product first');
    return;
  }
  const sensor = (document.getElementById('sensorSelect') as HTMLSelectElement).value;
  const url = `/api/products/${selectedProduct.id}/sensors?sensor=${sensor}`;
  const res = await fetch(url);
  const data = await res.json();

  const x = data.times; // seconds
  const y = data.values;

  const layout = { title: `${selectedProduct.name} - ${sensor}`, xaxis: { title: 'Seconds' }, yaxis: { title: sensor } };
  Plotly.newPlot('plot', [{ x, y, mode: 'lines' }], layout, { responsive: true });
}
