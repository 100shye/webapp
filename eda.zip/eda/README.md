# EDA - Production Viewer

Quick demo app to inspect daily production list and plot sensor time-series per product.

Run:

1. Create a Python environment and install backend deps:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

2. Build frontend (optional; `dist` contains a fallback):

```bash
cd static
npm install
npm run build
```

3. Start the server:

```bash
python -m uvicorn eda.app:app --reload --port 8005
```

Open http://127.0.0.1:8005
