import json
import plotly.graph_objects as go
import plotly.colors as pc
from typing import Dict

def get_color_map(tools):
    """툴 리스트를 받아 고유한 색상을 매핑"""
    palette = pc.qualitative.Plotly
    color_map = {}
    for i, tool in enumerate(sorted(tools)):
        color_map[tool] = palette[i % len(palette)]
    return color_map

def create_plotly_config(name, tool_history_dict: Dict[str, list], target_tool: str = None):
    """
    Target Tool은 빨간색, 나머지는 기본 색상(또는 흐린 색)으로 그리는 함수
    """
    fig = go.Figure()
    tools = list(tool_history_dict.keys())
    
    # 기본 팔레트
    palette = pc.qualitative.Plotly

    for i, tool in enumerate(tools):
        # [핵심 변경] Target Tool이면 빨간색/굵게, 아니면 일반 색상
        if tool == target_tool:
            line_color = '#FF0000' # 빨간색
            line_width = 4         # 두껍게
            opacity = 1.0
        else:
            # 타겟이 아닌 툴들은 색상을 순환하되, 타겟 강조를 위해 투명도 조절 가능
            line_color = palette[i % len(palette)]
            if line_color == '#FF0000' or line_color == 'red': # 우연히 팔레트가 빨강이면 변경
                line_color = '#999999'
            line_width = 2
            opacity = 0.6 # 약간 흐리게 하여 타겟 강조

        fig.add_trace(go.Scatter(
            y=tool_history_dict[tool],
            mode='lines+markers',
            name=tool,
            line=dict(color=line_color, width=line_width, shape='spline'),
            marker=dict(size=6, color='white', line=dict(width=2, color=line_color)),
            opacity=opacity
        ))

    fig.update_layout(
        title=dict(text=f"{name} Trend (Target: {target_tool})", font=dict(size=18, color='#333')),
        xaxis=dict(title='Time Step', showgrid=True, gridcolor='#eee'),
        yaxis=dict(title='Value', showgrid=True, gridcolor='#eee'),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
        margin=dict(l=40, r=20, t=50, b=40),
        showlegend=True,
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
    )
    return json.loads(fig.to_json())