// Color Palette
const COLORS = ['#636EFA', '#EF553B', '#00CC96', '#AB63FA', '#FFA15A', '#19D3F3', '#FF6692', '#B6E880', '#FF97FF', '#FECB52'];

// --- API Interaction Functions ---
function updateTargetToolOptions() {
    console.log("작동?");
    const toolSelect = document.getElementById("tool-select");
    const targetSelect = document.getElementById("target-tool-select");
    
    // 현재 선택된 툴 목록 가져오기
    const selectedTools = Array.from(toolSelect.selectedOptions).map(o => o.value);
    
    // 기존 선택값 기억
    const currentTarget = targetSelect.value;
    
    targetSelect.innerHTML = "";
    
    if (selectedTools.length === 0) {
        targetSelect.innerHTML = "<option disabled selected>Select tools above</option>";
        return;
    }
    
    selectedTools.forEach(tool => {
        const opt = document.createElement("option");
        opt.value = tool;
        opt.innerText = tool;
        targetSelect.appendChild(opt);
    });
    
    // 이전에 선택했던 값이 여전히 유효하면 유지, 아니면 첫번째 것 선택
    if (selectedTools.includes(currentTarget)) {
        targetSelect.value = currentTarget;
    } else {
        targetSelect.selectedIndex = 0;
    }
}

async function updateToolList() {
    const process = document.getElementById("process-select").value;
    const toolSelect = document.getElementById("tool-select");
    toolSelect.innerHTML = "<option>Loading...</option>";
    try {
        const res = await fetch(`/api/tools?process=${process}`);
        const data = await res.json();
        toolSelect.innerHTML = "";
        if(data.tools && data.tools.length) {
            data.tools.forEach(t => {
                const opt = document.createElement("option");
                opt.value = t; opt.innerText = t; toolSelect.appendChild(opt);
            });
        } else toolSelect.innerHTML = "<option disabled>No tools found</option>";
        updateRecipeList();
    } catch(e) { console.error(e); }
}

async function updateRecipeList() {
    const process = document.getElementById("process-select").value;
    const tools = Array.from(document.getElementById("tool-select").selectedOptions).map(o=>o.value);
    const recipeSelect = document.getElementById("recipe-select");
    
    if(!process || tools.length === 0) {
        recipeSelect.innerHTML = "<option disabled>Select Tools first</option>";
        return;
    }
    recipeSelect.innerHTML = "<option>Loading...</option>";
    try {
        const res = await fetch("/api/recipes", {
            method: "POST", headers: {"Content-Type":"application/json"},
            body: JSON.stringify({
                process: process, tools: tools,
                start_date: document.getElementById("start-date").value,
                end_date: document.getElementById("end-date").value
            })
        });
        const data = await res.json();
        recipeSelect.innerHTML = "";
        if(data.recipes && data.recipes.length) {
            data.recipes.forEach(r => {
                const opt = document.createElement("option");
                opt.value = r; opt.innerText = r; recipeSelect.appendChild(opt);
            });
        } else recipeSelect.innerHTML = "<option disabled>No recipes found</option>";
    } catch(e) { console.error(e); }
}

async function loadData() {
    const process = document.getElementById("process-select").value;
    const tools = Array.from(document.getElementById("tool-select").selectedOptions).map(o=>o.value);
    const recipes = Array.from(document.getElementById("recipe-select").selectedOptions).map(o=>o.value);
    const targetTool = document.getElementById("target-tool-select").value; 
    const issueType = document.getElementById("issue-select").value;

    if(!tools.length || !recipes.length) { alert("Select tools and recipes"); return; }
    if(!targetTool) { alert("Select a Target Tool for comparison"); return; }
    
    const btn = document.querySelector(".btn-primary");
    btn.innerText = "Comparing..."; btn.disabled = true;
    
    try {
        const res = await fetch("/api/load", {
            method: "POST", headers: {"Content-Type":"application/json"},
            body: JSON.stringify({
                process: process, tools: tools, recipes: recipes,
                start_date: document.getElementById("start-date").value,
                end_date: document.getElementById("end-date").value,
                target_tool: targetTool,
                issue_type: issueType 
            })
        });
        if(!res.ok) throw new Error((await res.json()).error);
        const treeData = await res.json();
        renderTree(treeData, targetTool); // targetTool 전달
    } catch(e) { alert(e.message); }
    finally { btn.innerText = "Compare Target vs Others"; btn.disabled = false; }
}

// renderTree 내부 수정 (리스트 표시 부분)
function renderTree(treeData, targetTool) {
    // ... (앞부분 동일) ...
    d3.select("#tree-wrapper").selectAll("*").remove();
    document.getElementById("list-content").innerHTML = "<div style='color:#999; text-align:center; margin-top:20px;'>Select a node</div>";
    Plotly.purge('plotly-chart');
    
    // ... (SVG, Root, Node 생성 부분 동일) ...
    const container = document.getElementById("tree-wrapper");
    const svg = d3.select("#tree-wrapper").append("svg")
        .attr("width", "100%").attr("height", "100%")
        .call(d3.zoom().on("zoom", (e) => g.attr("transform", e.transform)))
        .on("dblclick.zoom", null);
    const g = svg.append("g");
    
    const root = d3.hierarchy(treeData, d => d.children);
    const tree = d3.tree().nodeSize([40, 140]);
    const nodes = tree(root);

    const link = g.selectAll(".link").data(nodes.links()).enter().append("path")
        .attr("class", "link").attr("d", d3.linkHorizontal().x(d => d.y).y(d => d.x));

    const node = g.selectAll(".node").data(nodes.descendants()).enter().append("g")
        .attr("class", "node").attr("transform", d => `translate(${d.y},${d.x})`);

    node.append("circle").attr("r", 8)
        .on("click", function(event, d) {
            d3.selectAll("circle").classed("selected", false);
            d3.select(this).classed("selected", true);
            const ancestors = new Set(d.ancestors());
            link.classed("highlight", l => ancestors.has(l.target)).classed("dimmed", l => !ancestors.has(l.target));

            // Chart
            if (d.data.chart_config) {
                document.getElementById("placeholder").style.display = "none";
                Plotly.newPlot('plotly-chart', d.data.chart_config.data, d.data.chart_config.layout, {responsive: true});
            } else {
                Plotly.purge('plotly-chart');
                document.getElementById("placeholder").style.display = "block";
            }

            // [변경됨] Related List (Sorted by Diff)
            const listContent = document.getElementById("list-content");
            const listHeader = document.getElementById("list-header");
            listContent.innerHTML = "";
            
            if (d.data.related_sensors && d.data.related_sensors.length > 0) {
                // Header에 타겟 정보 표시
                listHeader.innerHTML = `${d.data.name}<br><small style='font-weight:normal; color:#d32f2f;'>Sorted by Diff (Target: ${targetTool})</small>`;
                
                d.data.related_sensors.forEach(sensor => {
                    const item = document.createElement("div");
                    item.className = "sensor-item";
                    
                    // Diff 값 표시 (소수점 1자리)
                    const diffVal = sensor.diff_value !== undefined ? Math.round(sensor.diff_value * 10) / 10 : 0;
                    
                    // Diff가 클수록 붉은색 강조
                    const diffColor = diffVal > 10 ? "#d32f2f" : "#666";
                    const diffStyle = diffVal > 10 ? "font-weight:bold;" : "";
                    
                    item.innerHTML = `
                        <span>${sensor.name}</span> 
                        <span style="color:${diffColor}; ${diffStyle} font-size:0.85em">
                            Diff: ${diffVal}
                        </span>`;
                        
                    item.onclick = () => {
                        document.querySelectorAll(".sensor-item").forEach(el => el.classList.remove("active"));
                        item.classList.add("active");
                        // drawClientSideChart에도 targetTool 정보를 넘겨서 색상을 맞출 수 있음 (현재는 단순 객체 순회라 순서대로 색칠됨)
                        drawClientSideChart(sensor.name, sensor.tool_history, targetTool);
                    };
                    listContent.appendChild(item);
                });
            } else {
                listHeader.innerText = "Related Sensors";
                listContent.innerHTML = "<div style='color:#999; text-align:center; margin-top:20px;'>No related sensors</div>";
            }
            
            // ... (Label 표시 부분 동일) ...
            d3.selectAll(".value-label-group").remove();
            if (d.data.score_map && Object.keys(d.data.score_map).length > 0) {
                // ... 기존 라벨 로직 ...
                 const scores = d.data.score_map;
                const tools = Object.keys(scores).sort();
                const numTools = tools.length;
                const boxHeight = (numTools * 12) + 8;
                const pg = d3.select(this.parentNode);
                const lg = pg.append("g").attr("class", "value-label-group").attr("transform", `translate(0, -${18 + boxHeight / 2})`);
                lg.append("rect").attr("class", "value-label-bg").attr("x", -37).attr("y", -boxHeight / 2).attr("width", 75).attr("height", boxHeight).attr("rx", 4);
                const textNode = lg.append("text").attr("class", "value-label-text").attr("text-anchor", "middle");
                tools.forEach((tool, i) => {
                    // 타겟 툴은 라벨에서도 강조할 수 있음 (여기선 단순히 표시)
                    textNode.append("tspan").attr("x", 0).attr("dy", i === 0 ? `-${(numTools - 1) * 0.6}em` : "1.2em").text(`${tool}: ${Math.round(scores[tool])}`);
                });
            }

            event.stopPropagation();
        });
        // ... (나머지 동일) ...
    node.append("text").attr("dy", ".35em").attr("x", d => d.children ? -12 : 12)
            .style("text-anchor", d => d.children ? "end" : "start").text(d => d.data.name);

    svg.call(d3.zoom().transform, d3.zoomIdentity.translate(40, container.clientHeight / 2));
}

// 클라이언트 사이드 차트 (Target Tool 색상 적용)
function drawClientSideChart(name, toolHistoryDict, targetTool) {
    const traces = [];
    const tools = Object.keys(toolHistoryDict).sort();
    
    // 색상 팔레트
    const COLORS = ['#636EFA', '#EF553B', '#00CC96', '#AB63FA', '#FFA15A', '#19D3F3'];

    tools.forEach((tool, index) => {
        let color, width, opacity;
        
        if (tool === targetTool) {
            color = '#FF0000'; // Target Red
            width = 4;
            opacity = 1.0;
        } else {
            color = COLORS[index % COLORS.length];
            if(color === '#FF0000') color = '#999'; // 빨간색 겹침 방지
            width = 2;
            opacity = 0.5;
        }

        traces.push({
            y: toolHistoryDict[tool],
            mode: 'lines+markers',
            name: tool,
            line: {color: color, width: width, shape: 'spline'},
            marker: {size: 6, color: 'white', line: {width: 2, color: color}},
            opacity: opacity
        });
    });

    const layout = {
        title: {text: `${name} (Target: ${targetTool})`, font: {size: 18, color: '#333'}},
        xaxis: {title: 'Time', showgrid: true, gridcolor: '#eee'},
        yaxis: {title: 'Value', showgrid: true, gridcolor: '#eee'},
        paper_bgcolor: 'rgba(0,0,0,0)', plot_bgcolor: 'rgba(0,0,0,0)',
        margin: {l: 40, r: 20, t: 50, b: 40}, 
        showlegend: true,
        legend: { orientation: "h", yanchor: "bottom", y: 1.02, xanchor: "right", x: 1 }
    };
    document.getElementById("placeholder").style.display = "none";
    Plotly.newPlot('plotly-chart', traces, layout, {responsive: true});
}