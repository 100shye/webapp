import json
import plotly.graph_objects as go
import plotly.colors as pc
from typing import Dict

def get_color_map(tools):
    """툴 리스트를 받아 고유한 색상을 매핑"""
    palette = pc.qualitative.Plotly
    color_map = {}
    for i, tool in enumerate(sorted(tools)):
        color_map[tool] = palette[i % len(palette)]
    return color_map

def create_plotly_config(name, tool_history_dict: Dict[str, list]):
    """툴 별 히스토리 데이터를 받아 Plotly JSON 설정 반환"""
    fig = go.Figure()
    tools = list(tool_history_dict.keys())
    color_map = get_color_map(tools)

    for tool, history in tool_history_dict.items():
        fig.add_trace(go.Scatter(
            y=history,
            mode='lines+markers',
            name=tool,
            line=dict(color=color_map[tool], width=2, shape='spline'),
            marker=dict(size=6, color='white', line=dict(width=2, color=color_map[tool]))
        ))

    fig.update_layout(
        title=dict(text=f"{name} Trend", font=dict(size=20, color='#333')),
        xaxis=dict(title='Time Step', showgrid=True, gridcolor='#eee'),
        yaxis=dict(title='Value', showgrid=True, gridcolor='#eee'),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
        margin=dict(l=50, r=30, t=60, b=50),
        showlegend=True,
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
    )
    return json.loads(fig.to_json())