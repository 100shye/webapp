from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from typing import List

# 로직 분리 모듈 임포트
import data_load

app = FastAPI()

# 정적 파일 마운트 (css, js)
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# ---------------------------------------------------------
# Request Models
# ---------------------------------------------------------
class RecipeFilterRequest(BaseModel):
    process: str
    tools: List[str]
    start_date: str
    end_date: str

class LoadRequest(BaseModel):
    process: str
    tools: List[str]
    start_date: str
    end_date: str
    recipes: List[str]

# ---------------------------------------------------------
# API Endpoints
# ---------------------------------------------------------
@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/api/tools")
async def get_tools_api(process: str):
    print('tool')
    tools = data_load.get_tool_list(process)
    return JSONResponse({"tools": tools})

@app.post("/api/recipes")
async def get_recipes_api(req: RecipeFilterRequest):
    recipes = data_load.get_recipe_list(req.process, req.tools, req.start_date, req.end_date)
    return JSONResponse({"recipes": recipes})

@app.post("/api/load")
async def load_data_api(req: LoadRequest):
    try:
        tree_structure = data_load.build_tree_data(
            req.process, req.tools, req.recipes, req.start_date, req.end_date
        )
        if tree_structure is None:
            return JSONResponse({"error": "No matching files found"}, status_code=404)
        
        return JSONResponse(tree_structure)
        
    except ValueError as e:
        return JSONResponse({"error": str(e)}, status_code=400)
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)