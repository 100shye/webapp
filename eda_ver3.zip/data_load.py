import os
import random
import pandas as pd
import pyarrow.parquet as pq
from datetime import datetime, timedelta
from typing import List, Dict

# 그래프 설정 함수 임포트
from plot_func import create_plotly_config

STORAGE_ROOT = "./storage"
SCORE_ROOT = os.path.join(STORAGE_ROOT, "score")

def parse_filename(filename):
    """파일명에서 tool, date, recipe 추출"""
    try:
        name_without_ext = filename.replace(".parquet", "")
        parts = name_without_ext.split("_")
        if len(parts) < 3: return None, None, None
        tool = parts[0]
        date_str = parts[1]
        recipe = "_".join(parts[2:])
        date_obj = datetime.strptime(date_str, "%Y-%m-%d").date()
        return tool, date_obj, recipe
    except:
        return None, None, None

def generate_related_history_by_tool(base_val_dict, length=20):
    """연관 센서용 더미 데이터 생성"""
    result = {}
    for tool, base_val in base_val_dict.items():
        if base_val is None: base_val = 50
        result[tool] = [base_val + random.randint(-5, 5) for _ in range(length)]
    return result

def load_tool_specific_scores(start_date, end_date, selected_tools):
    """
    선택된 기간/툴의 점수를 읽어 센서별 & 툴별 점수 딕셔너리 반환
    Returns: {'top temp': {'toolA': 85.0, 'toolB': 92.5}, ...}
    """
    scores_list = []
    current = start_date
    while current <= end_date:
        score_file = os.path.join(SCORE_ROOT, f"{current.strftime('%Y-%m-%d')}_score.parquet")
        if os.path.exists(score_file):
            try:
                df = pq.read_table(score_file).to_pandas()
                filtered_df = df[df['ToolName'].isin(selected_tools)]
                if not filtered_df.empty:
                    scores_list.append(filtered_df)
            except Exception as e:
                print(f"Error reading score {score_file}: {e}")
        current += timedelta(days=1)
        
    if not scores_list: return {}

    full_score_df = pd.concat(scores_list)
    
    # 툴별로 그룹화한 뒤, 각 센서의 평균 점수 계산
    avg_scores_by_tool = full_score_df.groupby('ToolName').mean(numeric_only=True)
    
    # 최종 결과 구조로 변환: {'sensor': {'tool': score}}
    result_dict = {}
    for sensor_name in avg_scores_by_tool.columns:
        # 각 센서(컬럼)에 대한 툴별 점수를 딕셔너리로 변환
        result_dict[sensor_name] = avg_scores_by_tool[sensor_name].to_dict()
        
    return result_dict


def build_tree_data(process, tools, recipes, start_date_str, end_date_str):
    """
    메인 로직: 파일을 찾아 읽고, 병합하고, 점수를 매겨 트리 구조(Dict) 반환
    """
    try:
        s_date = datetime.strptime(start_date_str, "%Y-%m-%d").date()
        e_date = datetime.strptime(end_date_str, "%Y-%m-%d").date()
    except ValueError:
        raise ValueError("Invalid date format")

    # 1. 파일 수집
    files_to_read = []
    for tool in tools:
        tool_dir = os.path.join(STORAGE_ROOT, process, tool)
        if not os.path.exists(tool_dir): continue
        for f in os.listdir(tool_dir):
            if f.endswith(".parquet"):
                f_tool, f_date, f_recipe = parse_filename(f)
                if f_tool and f_date:
                    if s_date <= f_date <= e_date and f_recipe in recipes:
                        files_to_read.append({"path": os.path.join(tool_dir, f), "tool": f_tool})

    if not files_to_read:
        return None  # 또는 예외 발생

    # 2. 데이터 읽기
    dfs = [pd.read_parquet(item["path"]).assign(tool_name=item["tool"]) for item in files_to_read]
    full_df = pd.concat(dfs)

    # 3. 점수 데이터 로드
    tool_scores = load_tool_specific_scores(s_date, e_date, tools)

    # 4. 데이터 병합 및 구조화
    merged_rows = []
    for (group, sensor), sub_df in full_df.groupby(['group', 'sensor']):
        tool_history_map = {
            tool_name: [float(x) for h in tool_df['history'] for x in h]
            for tool_name, tool_df in sub_df.groupby('tool_name')
        }
        tool_last_value_map = {
            name: float(hist[-1]) if hist else 0.0 for name, hist in tool_history_map.items()
        }
        avg_val = float(sum(tool_last_value_map.values()) / len(tool_last_value_map)) if tool_last_value_map else 0.0
        
        # [변경됨] 센서에 해당하는 툴별 점수 맵을 가져옴
        score_map_for_sensor = tool_scores.get(sensor, {})

        merged_rows.append({
            "group": group, "sensor": sensor,
            "tool_history": tool_history_map,
            "tool_values": tool_last_value_map,
            "avg_value": avg_val,
            "score_map": score_map_for_sensor  # 평균 대신 맵 전달
        })
    
    merged_df = pd.DataFrame(merged_rows)

    # 5. 트리 JSON 생성
    groups = merged_df.groupby('group')
    children_list = []
    for group_name, group_df in groups:
        sensors = []
        for _, row in group_df.iterrows():
            chart_config = create_plotly_config(row['sensor'], row['tool_history'])
            
            related_sensors = []
            for i in range(1, 41):
                rel_name = f"{row['sensor']}_sub_{i:02d}"
                rel_tool_history = generate_related_history_by_tool(row['tool_values'])
                # 연관 센서는 대표값(평균)으로 표시
                scores = row['score_map'].values()
                rel_avg_score = sum(scores) / len(scores) if scores else 0

                related_sensors.append({
                    "name": rel_name,
                    "avg_score_value": rel_avg_score,
                    "tool_history": rel_tool_history
                })

            sensors.append({
                "name": row['sensor'],
                "value": row['avg_value'],
                "score_map": row['score_map'], # [변경됨] score_map 전달
                "chart_config": chart_config,
                "related_sensors": related_sensors,
                "type": "sensor"
            })
        children_list.append({ "name": group_name, "children": sensors, "type": "group" })

    return { "name": f"{process} Analysis", "children": children_list, "type": "root" }

# (get_tool_list, get_recipe_list 함수는 기존과 동일)
def get_tool_list(process):
    proc_dir = os.path.join(STORAGE_ROOT, process)
    if not os.path.exists(proc_dir): return []
    return sorted([d for d in os.listdir(proc_dir) if os.path.isdir(os.path.join(proc_dir, d))])


def get_recipe_list(process, tools, start_date_str, end_date_str):
    """조건에 맞는 레시피 목록 반환"""
    available_recipes = set()
    try:
        s_date = datetime.strptime(start_date_str, "%Y-%m-%d").date()
        e_date = datetime.strptime(end_date_str, "%Y-%m-%d").date()
    except ValueError:
        return []

    for tool in tools:
        tool_dir = os.path.join(STORAGE_ROOT, process, tool)
        if not os.path.exists(tool_dir): continue
        for f in os.listdir(tool_dir):
            if f.endswith(".parquet"):
                f_tool, f_date, f_recipe = parse_filename(f)
                if f_tool and f_date:
                    if s_date <= f_date <= e_date:
                        available_recipes.add(f_recipe)
    return sorted(list(available_recipes))