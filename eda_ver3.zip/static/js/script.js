// Color Palette
const COLORS = ['#636EFA', '#EF553B', '#00CC96', '#AB63FA', '#FFA15A', '#19D3F3', '#FF6692', '#B6E880', '#FF97FF', '#FECB52'];

// --- API Interaction Functions ---

async function updateToolList() {
    const process = document.getElementById("process-select").value;
    const toolSelect = document.getElementById("tool-select");
    toolSelect.innerHTML = "<option>Loading...</option>";
    try {
        const res = await fetch(`/api/tools?process=${process}`);
        const data = await res.json();
        toolSelect.innerHTML = "";
        if(data.tools && data.tools.length) {
            data.tools.forEach(t => {
                const opt = document.createElement("option");
                opt.value = t; opt.innerText = t; toolSelect.appendChild(opt);
            });
        } else toolSelect.innerHTML = "<option disabled>No tools found</option>";
        updateRecipeList();
    } catch(e) { console.error(e); }
}

async function updateRecipeList() {
    const process = document.getElementById("process-select").value;
    const tools = Array.from(document.getElementById("tool-select").selectedOptions).map(o=>o.value);
    const recipeSelect = document.getElementById("recipe-select");
    
    if(!process || tools.length === 0) {
        recipeSelect.innerHTML = "<option disabled>Select Tools first</option>";
        return;
    }
    recipeSelect.innerHTML = "<option>Loading...</option>";
    try {
        const res = await fetch("/api/recipes", {
            method: "POST", headers: {"Content-Type":"application/json"},
            body: JSON.stringify({
                process: process, tools: tools,
                start_date: document.getElementById("start-date").value,
                end_date: document.getElementById("end-date").value
            })
        });
        const data = await res.json();
        recipeSelect.innerHTML = "";
        if(data.recipes && data.recipes.length) {
            data.recipes.forEach(r => {
                const opt = document.createElement("option");
                opt.value = r; opt.innerText = r; recipeSelect.appendChild(opt);
            });
        } else recipeSelect.innerHTML = "<option disabled>No recipes found</option>";
    } catch(e) { console.error(e); }
}

async function loadData() {
    const process = document.getElementById("process-select").value;
    const tools = Array.from(document.getElementById("tool-select").selectedOptions).map(o=>o.value);
    const recipes = Array.from(document.getElementById("recipe-select").selectedOptions).map(o=>o.value);
    
    if(!tools.length || !recipes.length) { alert("Select tools and recipes"); return; }
    
    const btn = document.querySelector(".btn-primary");
    btn.innerText = "Loading..."; btn.disabled = true;
    
    try {
        const res = await fetch("/api/load", {
            method: "POST", headers: {"Content-Type":"application/json"},
            body: JSON.stringify({
                process: process, tools: tools, recipes: recipes,
                start_date: document.getElementById("start-date").value,
                end_date: document.getElementById("end-date").value
            })
        });
        if(!res.ok) throw new Error((await res.json()).error);
        const treeData = await res.json();
        renderTree(treeData);
    } catch(e) { alert(e.message); }
    finally { btn.innerText = "Load Scores & Data"; btn.disabled = false; }
}

// --- Visualization Functions (D3 & Plotly) ---

function renderTree(treeData) {
    // ... (상단 초기화 부분은 기존과 동일) ...
    d3.select("#tree-wrapper").selectAll("*").remove();
    document.getElementById("list-content").innerHTML = "<div style='color:#999; text-align:center; margin-top:20px;'>Select a node</div>";
    Plotly.purge('plotly-chart');
    
    const container = document.getElementById("tree-wrapper");
    const svg = d3.select("#tree-wrapper").append("svg")
        .attr("width", "100%").attr("height", "100%")
        .call(d3.zoom().on("zoom", (e) => g.attr("transform", e.transform)))
        .on("dblclick.zoom", null);
    const g = svg.append("g");
    
    const root = d3.hierarchy(treeData, d => d.children);
    const tree = d3.tree().nodeSize([40, 140]);
    const nodes = tree(root);

    const link = g.selectAll(".link").data(nodes.links()).enter().append("path")
        .attr("class", "link").attr("d", d3.linkHorizontal().x(d => d.y).y(d => d.x));

    const node = g.selectAll(".node").data(nodes.descendants()).enter().append("g")
        .attr("class", "node").attr("transform", d => `translate(${d.y},${d.x})`);

    node.append("circle").attr("r", 8)
        .on("click", function(event, d) {
            d3.selectAll("circle").classed("selected", false);
            d3.select(this).classed("selected", true);
            const ancestors = new Set(d.ancestors());
            link.classed("highlight", l => ancestors.has(l.target)).classed("dimmed", l => !ancestors.has(l.target));

            // 1. Chart (기존과 동일)
            if (d.data.chart_config) {
                document.getElementById("placeholder").style.display = "none";
                Plotly.newPlot('plotly-chart', d.data.chart_config.data, d.data.chart_config.layout, {responsive: true});
            } else {
                Plotly.purge('plotly-chart');
                document.getElementById("placeholder").style.display = "block";
            }

            // 2. Related List (표시값 수정)
            const listContent = document.getElementById("list-content");
            const listHeader = document.getElementById("list-header");
            listContent.innerHTML = "";
            if (d.data.related_sensors && d.data.related_sensors.length > 0) {
                listHeader.innerText = `${d.data.name} (Related)`;
                d.data.related_sensors.forEach(sensor => {
                    const item = document.createElement("div");
                    item.className = "sensor-item";
                    const valText = sensor.avg_score_value !== undefined ? `Avg Score: ${Math.round(sensor.avg_score_value)}` : "";
                    item.innerHTML = `<span>${sensor.name}</span> <span style="color:#666; font-size:0.8em">${valText}</span>`;
                    item.onclick = () => {
                        document.querySelectorAll(".sensor-item").forEach(el => el.classList.remove("active"));
                        item.classList.add("active");
                        drawClientSideChart(sensor.name, sensor.tool_history);
                    };
                    listContent.appendChild(item);
                });
            } else {
                listHeader.innerText = "Related Sensors";
                listContent.innerHTML = "<div style='color:#999; text-align:center; margin-top:20px;'>No related sensors</div>";
            }

            // [변경됨] 3. Label (여러 툴 점수 표시)
            d3.selectAll(".value-label-group").remove();
            
            if (d.data.score_map && Object.keys(d.data.score_map).length > 0) {
                const scores = d.data.score_map;
                const tools = Object.keys(scores).sort(); // toolA, toolB 순서 보장
                
                const numTools = tools.length;
                const lineHeight = 12; // 한 줄 높이
                const boxPadding = 4;
                const boxHeight = (numTools * lineHeight) + (boxPadding * 2);
                const boxWidth = 75; // 넉넉하게

                const pg = d3.select(this.parentNode);
                const lg = pg.append("g").attr("class", "value-label-group")
                             .attr("transform", `translate(0, -${18 + boxHeight / 2})`); // 라벨 위치 조정

                // 배경 박스 (동적 높이)
                lg.append("rect").attr("class", "value-label-bg")
                  .attr("x", -boxWidth / 2)
                  .attr("y", -boxHeight / 2)
                  .attr("width", boxWidth)
                  .attr("height", boxHeight)
                  .attr("rx", 4);

                // 텍스트 (여러 줄 tspan 사용)
                const textNode = lg.append("text")
                  .attr("class", "value-label-text")
                  .attr("text-anchor", "middle");

                // 각 툴에 대해 tspan 생성
                tools.forEach((tool, i) => {
                    textNode.append("tspan")
                      .attr("x", 0)
                      .attr("dy", i === 0 ? `-${(numTools - 1) * 0.6}em` : "1.2em") // 첫 줄 위치 조정, 나머지는 상대 위치
                      .text(`${tool}: ${Math.round(scores[tool])}`);
                });
            }
            event.stopPropagation();
        });

    // ... (node.append("text") 부분은 기존과 동일) ...
    node.append("text").attr("dy", ".35em").attr("x", d => d.children ? -12 : 12)
            .style("text-anchor", d => d.children ? "end" : "start").text(d => d.data.name);

    svg.call(d3.zoom().transform, d3.zoomIdentity.translate(40, container.clientHeight / 2));
}

function drawClientSideChart(name, toolHistoryDict) {
    const traces = [];
    const tools = Object.keys(toolHistoryDict).sort();
    tools.forEach((tool, index) => {
        const color = COLORS[index % COLORS.length];
        traces.push({
            y: toolHistoryDict[tool], mode: 'lines+markers', name: tool,
            line: {color: color, width: 2, shape: 'spline'},
            marker: {size: 6, color: 'white', line: {width: 2, color: color}}
        });
    });
    const layout = {
        title: {text: `${name} Trend`, font: {size: 18, color: '#333'}},
        xaxis: {title: 'Time', showgrid: true, gridcolor: '#eee'},
        yaxis: {title: 'Value', showgrid: true, gridcolor: '#eee'},
        paper_bgcolor: 'rgba(0,0,0,0)', plot_bgcolor: 'rgba(0,0,0,0)',
        margin: {l: 40, r: 20, t: 50, b: 40}, showlegend: true,
        legend: { orientation: "h", yanchor: "bottom", y: 1.02, xanchor: "right", x: 1 }
    };
    document.getElementById("placeholder").style.display = "none";
    Plotly.newPlot('plotly-chart', traces, layout, {responsive: true});
}